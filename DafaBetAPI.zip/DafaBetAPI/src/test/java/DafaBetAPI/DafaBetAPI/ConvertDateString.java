package DafaBetAPI.DafaBetAPI;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
 
public class ConvertDateString {
 
	
	@Test
	public void ConvertFromDateStringtoUnixTimeStamp_VerifyStatusCode() throws ParseException {
		
		
		RequestSpecification request= RestAssured.given();
		
		request.baseUri("https://helloacm.com/api/unix-timestamp-converter/?cached&s=2016-01-01%202:3:22");
		
		Response response = request.get();
		
		// Let's print response body.
		String resString = response.asString();
		System.out.println("Respnse Details : " + resString);
 
		ValidatableResponse valRes = response.then();
		valRes.statusCode(200);
		valRes.statusLine("HTTP/1.1 200 OK");
		
 
	}
 
}
