package DafaBetAPI.DafaBetAPI;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;
 
public class InvalidDateString {
 
	@Test
	public void WhenpassingInvalidDateString_VerifyStatusCode() {
		
		
		RequestSpecification request= RestAssured.given();
		
		request.baseUri("https://helloacm.com/api/unix-timestamp-converter/?cached&s=asdfasd");
		
		Response response = request.get();
		
		// Let's print response body.
		String resString = response.asString();
		System.out.println("Respnse Details : " + resString);
 
		ValidatableResponse valRes = response.then();
		valRes.statusCode(200);
		valRes.statusLine("HTTP/1.1 200 OK");
		
		Assert False;
		
 
	}
 
}
