package DafaBetAPI.DafaBetAPI;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
 
public class ConvertTimeStamp {
 
	@Test
	public void ConvertUnixTimeStampToDateString_VerifyStatusCode() {
		
		
		RequestSpecification request= RestAssured.given();
		
		request.baseUri("https://helloacm.com/api/unix-timestamp-converter/?cached&s=1451613802");
		
		Response response = request.get();
		
		// Let's print response body.
		String resString = response.asString();
		System.out.println("Respnse Details : " + resString);
 

		ValidatableResponse valRes = response.then();
		valRes.statusCode(200);
		valRes.statusLine("HTTP/1.1 200 OK");
		
 
	}
 
}
