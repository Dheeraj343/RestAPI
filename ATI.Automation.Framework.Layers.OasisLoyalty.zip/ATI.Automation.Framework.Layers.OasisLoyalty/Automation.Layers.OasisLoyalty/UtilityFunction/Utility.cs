﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Automation.Layers.OasisLoyalty.UtilityFunction
{
    class Utility
    {
        private static Random random = new Random();
        public static string RandomIntString(int length)
        {
            const string chars = "0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public static string RandomTextString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
