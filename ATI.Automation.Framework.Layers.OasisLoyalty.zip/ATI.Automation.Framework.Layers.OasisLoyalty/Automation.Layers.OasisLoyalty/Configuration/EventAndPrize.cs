﻿using System;
using TechTalk.SpecFlow;
using Microsoft.Extensions.DependencyInjection;
using Automation.Framework.Core.Web.WebAbstraction;
using Automation.Framework.Core.Web.Runner;
using System.Collections.Generic;
using Automation.Layers.OasisLoyalty.UtilityFunction;


namespace Automation.Layers.OasisLoyalty.Configuration
{
    [Binding]
    public class EventAndPrize : LoyaltyBase
    {

        IWebStepDef _iwebstep;
        ITestStep _iteststep;
        ITestStepBuilder _iteststepbuilder;

        Dictionary<string, string> _prizedata = new Dictionary<string, string>();
        Dictionary<string, string> _eventdata = new Dictionary<string, string>();
        Dictionary<string, string> _RedeemPrize_data = new Dictionary<string, string>();
        Dictionary<string, string> _ReturnPrize_data = new Dictionary<string, string>();


        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();

        }

        [When(@"Loyalty User Create a Prize with name ""(.*)""  which is charged from bucket ""(.*)"" with parameters")]
        private void CreatePrize(string name, string bucket, Table datatables)
        {
            //Table should have data of prizes 
            //prizetype , fulfillmentype, maxRedeemperevent , requiredCost ,actualcost , inventory , successmessage

            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            _prizedata = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONFIGURATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("CONFIGURATION_SUB_NAV_BOX.EVENT_MANAGEMENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.MANAGE_PRIZES_LINK");
            _iwebstep.GetService().GivenUserClicksOn("PRIZE_MANAGEMENT_SUB_NAV_BOX.ADD_PRIZE_LINK");
            _iwebstep.GetService().ThenUserWaits("5");
            _iwebstep.GetService().GivenUserEntersText(name, "PRIZE_MANAGEMENT_SUB_NAV_BOX.PRIZENAME_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("5");
            _iwebstep.GetService().GivenUserClicksOn("PRIZE_MANAGEMENT_SUB_NAV_BOX.PRIZEDESCRIPTION_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("10");
            _iwebstep.GetService().GivenUserEntersText("Automation" + name, "PRIZE_MANAGEMENT_SUB_NAV_BOX.PRIZEDESCRIPTION_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_prizedata["fulfillmentype"], "PRIZE_MANAGEMENT_SUB_NAV_BOX.FULFILLMENTYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("PRIZE_MANAGEMENT_SUB_NAV_BOX.ONHAND_INVENTORY_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText(_prizedata["inventory"], "PRIZE_MANAGEMENT_SUB_NAV_BOX.ONHAND_INVENTORY_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("PRIZE_MANAGEMENT_SUB_NAV_BOX.DROPSHIP_INVENTORY_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(_prizedata["inventory"], "PRIZE_MANAGEMENT_SUB_NAV_BOX.DROPSHIP_INVENTORY_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("PRIZE_MANAGEMENT_SUB_NAV_BOX.MAXREDEEMAMOUNT_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(_prizedata["maxredeemperevent"], "PRIZE_MANAGEMENT_SUB_NAV_BOX.MAXREDEEMAMOUNT_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("10", "PRIZE_MANAGEMENT_SUB_NAV_BOX.PRIZEVALUE_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(_prizedata["requiredcost"], "PRIZE_MANAGEMENT_SUB_NAV_BOX.REQUIREDCOST_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(bucket, "PRIZE_MANAGEMENT_SUB_NAV_BOX.lstBucketType", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserClears("PRIZE_MANAGEMENT_SUB_NAV_BOX.ACTUALCOST_TEXTVALUE");
            _iwebstep.GetService().GivenUserEntersText(_prizedata["actualcost"], "PRIZE_MANAGEMENT_SUB_NAV_BOX.ACTUALCOST_TEXTVALUE");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(bucket, "PRIZE_MANAGEMENT_SUB_NAV_BOX.lstActualCostBucketType", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("PRIZE_MANAGEMENT_SUB_NAV_BOX.PRIZEDEFINITION_SAVEBUTTON");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", _prizedata["successmessage"], "PRIZE_MANAGEMENT_SUB_NAV_BOX.EVENT_CREATION_SUCCESS_MESSAGE");
            _iwebstep.GetService().GivenUserClicksOn("PRIZE_MANAGEMENT_SUB_NAV_BOX.btn_SucessOk");



        }

        [When(@"Loyalty User Create a Event with name ""(.*)""  with prize name ""(.*)"" and with parameters")]
        private void CreateEvent(string name, string prizename, Table datatables)
        {
            /* Datatable should have 
             
             eventname
             eventdescription
             earningperiodtype
             earningeventstartdate
             earningeventstarttime
             earningeventenddate
             earningeventendtime
             redemptionperiodtype
             redemptionperiodstartdate
             redemptionperiodstarttime
             redemptionperiodenddate
             redemptionperiodendtime
             prizecriteria
             prizecriteriafrom
             prizecriteriato
             playerid 
             blackList
             redemptionperiodsameasearningperiod */


            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            _eventdata = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONFIGURATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("CONFIGURATION_SUB_NAV_BOX.EVENT_MANAGEMENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.CONFIGURE_EVENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_EVENT_LINK");
            _iwebstep.GetService().GivenUserEntersText(name, "EVENT_MANAGEMENT_SUB_NAV_BOX.EVENT_NAME_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("Description" + name, "EVENT_MANAGEMENT_SUB_NAV_BOX.EVENT_DESCRIPTION_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.EVENT_DETAIL_SAVE_BUTTON");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", "Event Definition Saved.", "EVENT_MANAGEMENT_SUB_NAV_BOX.EVENT_CREATION_SUCCESS_MESSAGE");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.EVENT_SCHEDULE_LINK");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_EVENT_LINK");
            _iwebstep.GetService().ThenUserWaits("10");

            if (_eventdata["redemptionperiodsameasearningperiod"] == "Y")
            {

                _iwebstep.GetService().GivenUserEntersText(_eventdata["earningeventstartdate"], "EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_FROM_CALENDAR");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtEarningPeriodFromDate').value='" + _eventdata["earningeventstartdate"] + "'");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(_eventdata["earningeventstarttime"], "EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_FROMTIME_TEXT");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(_eventdata["earningeventenddate"], "EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_TO_CALENDAR");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtEarningPeriodToDate').value='" + _eventdata["earningeventenddate"] + "'");
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_TOTIME_TEXT");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserEntersText(_eventdata["earningeventendtime"], "EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_TOTIME_TEXT");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.REDEMPTION_CHECKBOX");

            }
            else
            {
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["earningperiodtype"], "EVENT_MANAGEMENT_SUB_NAV_BOX.lst_EarningPeriodType", "visibletext");
                //_iwebstep.GetService().GivenUserEntersText(_eventdata["earningeventstartdate"], "EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_FROM_CALENDAR");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtEarningPeriodFromDate').value='" + _eventdata["earningeventstartdate"] + "'");
                _iwebstep.GetService().ThenUserWaits("3");
                _iwebstep.GetService().GivenUserEntersText(_eventdata["earningeventstarttime"], "EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_FROMTIME_TEXT");
                _iwebstep.GetService().ThenUserWaits("2");
                //_iwebstep.GetService().GivenUserEntersText(_eventdata["earningeventenddate"], "EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_TO_CALENDAR");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtEarningPeriodToDate').value='" + _eventdata["earningeventenddate"] + "'");
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserEntersText(_eventdata["earningeventendtime"], "EVENT_MANAGEMENT_SUB_NAV_BOX.EARNINGPERIOD_TOTIME_TEXT");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["redemptionperiodtype"], "EVENT_MANAGEMENT_SUB_NAV_BOX.lst_RedemptionPeriodType", "visibletext");
                //_iwebstep.GetService().GivenUserEntersText(_eventdata["redemptionperiodstartdate"], "EVENT_MANAGEMENT_SUB_NAV_BOX.RedemptionPeriod_FromDate");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtRedemptionPeriodFromDate').value='" + _eventdata["redemptionperiodstartdate"] + "'");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(_eventdata["redemptionperiodstarttime"], "EVENT_MANAGEMENT_SUB_NAV_BOX.RedemptionPeriod_StartTime");
                _iwebstep.GetService().ThenUserWaits("4");
                // _iwebstep.GetService().GivenUserEntersText(_eventdata["redemptionperiodenddate"], "EVENT_MANAGEMENT_SUB_NAV_BOX.RedemptionPeriod_EndDate");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtRedemptionPeriodToDate').value='" + _eventdata["redemptionperiodenddate"] + "'");
                _iwebstep.GetService().ThenUserWaits("5");
                _iwebstep.GetService().GivenUserEntersText(_eventdata["redemptionperiodendtime"], "EVENT_MANAGEMENT_SUB_NAV_BOX.RedemptionPeriod_EndTime");


            }

            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.SCHEDULE_SAVE_BUTTON");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.EVENT_SCHEDULE_SUCCESS_MESSAGE");

            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.PRIZECRITERIA_LINK");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_EVENT_LINK");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(prizename, "EVENT_MANAGEMENT_SUB_NAV_BOX.PRIZENAME_SELECTBOX", "visibletext");

            if (!(_eventdata["prizecriteria"].Equals("")))
            {
                _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.imgAddCriteria");
                _iwebstep.GetService().ThenUserWaits("2");
                switch (_eventdata["prizecriteria"])
                {
                    case "Age":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["prizecriteria"], "EVENT_MANAGEMENT_SUB_NAV_BOX.lstSelectCriteria", "visibletext");
                        _iwebstep.GetService().ThenUserWaits("2");
                        _iwebstep.GetService().GivenUserEntersText(_eventdata["prizecriteriafrom"], "EVENT_MANAGEMENT_SUB_NAV_BOX.txtAgeCriteriaFrom");
                        _iwebstep.GetService().GivenUserEntersText(_eventdata["prizecriteriato"], "EVENT_MANAGEMENT_SUB_NAV_BOX.txtAgeCriteriaTo");
                        break;
                    case "Bucket":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["prizecriteria"], "EVENT_MANAGEMENT_SUB_NAV_BOX.lstSelectCriteria", "visibletext");
                        _iwebstep.GetService().ThenUserWaits("2");
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["prizecriteriafrom"], "EVENT_MANAGEMENT_SUB_NAV_BOX.Select_Criteria_dropdown_from", "visibletext");
                        _iwebstep.GetService().GivenUserEntersText(_eventdata["prizecriteriato"], "EVENT_MANAGEMENT_SUB_NAV_BOX.txtAgeCriteriaTo");
                        break;
                    case "Max prizes per player per event":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["prizecriteria"], "EVENT_MANAGEMENT_SUB_NAV_BOX.lstSelectCriteria", "visibletext");
                        _iwebstep.GetService().ThenUserWaits("2");
                        _iwebstep.GetService().GivenUserEntersText(_eventdata["prizecriteriafrom"], "EVENT_MANAGEMENT_SUB_NAV_BOX.txtAgeCriteriaFrom");
                        break;
                    case "Tier":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["prizecriteria"], "EVENT_MANAGEMENT_SUB_NAV_BOX.lstSelectCriteria", "visibletext");
                        _iwebstep.GetService().ThenUserWaits("2");
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["prizecriteriafrom"], "EVENT_MANAGEMENT_SUB_NAV_BOX.Select_Criteria_dropdown_from", "visibletext");
                        _iwebstep.GetService().GivenUserEntersText(_eventdata["prizecriteriato"], "EVENT_MANAGEMENT_SUB_NAV_BOX.select_Criteria_dropdown_to");
                        break;
                    case "Zip Code":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_eventdata["prizecriteria"], "EVENT_MANAGEMENT_SUB_NAV_BOX.lstSelectCriteria", "visibletext");
                        _iwebstep.GetService().ThenUserWaits("2");
                        _iwebstep.GetService().GivenUserEntersText(_eventdata["prizecriteriafrom"], "EVENT_MANAGEMENT_SUB_NAV_BOX.txtAgeCriteriaFrom");
                        _iwebstep.GetService().GivenUserEntersText(_eventdata["prizecriteriato"], "EVENT_MANAGEMENT_SUB_NAV_BOX.txtAgeCriteriaTo");
                        break;


                }

            }

            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.PRIZECRITERIA_SAVE_BUTTON");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.PRIZECRITERIA_SUCCESS_LABEL");

            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.LIST_LINK");
            _iwebstep.GetService().ThenUserWaits("4");

            if (_eventdata["blacklist"].Equals("Y"))
            {
                _iwebstep.GetService().GivenUserEntersText(_eventdata["playerid"], "EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_PLAYERID_TEXTBOX");
                _iwebstep.GetService().GivenUserEntersText(_eventdata["playerid"], "EVENT_MANAGEMENT_SUB_NAV_BOX.chk_MarkPlayer_Blacklist");
                _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_PLAYERID_BUTTON");
            }
            else
            {
                _iwebstep.GetService().GivenUserEntersText(_eventdata["playerid"], "EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_PLAYERID_TEXTBOX");
                _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_PLAYERID_BUTTON");

            }



        }

        [When(@"Loyalty User With PlayerID ""(.*)"" Redeem a Prize of name ""(.*)"" of Quantity ""(.*)"" where function Authorization check is ""(.*)"" with parameters")]
        private void RedeemPrize(string PlayerID, string Prizename, string Qty, string functionauthCheck, Table Datatable)
        {
            /* Datatable should have 
             
             * prizetype
             * reason
             * comment
          
             */
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(Datatable).Build();
            _RedeemPrize_data = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONFIGURATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("CONFIGURATION_SUB_NAV_BOX.EVENT_MANAGEMENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.REDEEM_PRIZES_LINK");
            _iwebstep.GetService().GivenUserEntersText(PlayerID, "REDEEMPRIZES.REDEEM_PLAYERID");
            _iwebstep.GetService().GivenUserClicksOn("REDEEMPRIZES.FINDPLAYER_BUTTON");
            _iwebstep.GetService().ThenUserWaits("5");
            _iwebstep.GetService().GivenUserClicksOn("REDEEMPRIZES.REDEEMABLEEVENTS_GRID");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserEntersText(Qty, "REDEEMPRIZES.POINTS_QUANTITY_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("05");
            _iwebstep.GetService().WhenUserPressKey("Enter");
            _iwebstep.GetService().ThenUserWaits("10");

            if (_RedeemPrize_data["prizetype"] == "May Drop Ship" || _RedeemPrize_data["prizetype"] == "Must Drop Ship")
            {
                String Phoneno = Utility.RandomIntString(10);
                String zipcode = Utility.RandomIntString(5);
                String city = Utility.RandomTextString(6);

                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_grdRedeemDetail_ctl02_imgBtnShippingCost').click()");
                _iwebstep.GetService().ThenUserWaits("3");
                _iwebstep.GetService().GivenUserClicksOn("REDEEMPRIZES.chkDropshiprize");

                _iwebstep.GetService().GivenUserEntersText(city + "" + city + "" + city, "REDEEMPRIZES.txtDropshipaddress");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(city, "REDEEMPRIZES.txtDropcity");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(city, "REDEEMPRIZES.txtDropstate");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(zipcode, "REDEEMPRIZES.txtDropzipcode");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(city, "REDEEMPRIZES.txtDropcountry");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(Phoneno, "REDEEMPRIZES.txtDropphoneno");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText("Abc@gmail.com", "REDEEMPRIZES.txtEmailID");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_btnShippingAddress').click()");
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserClicksOn("REDEEMPRIZES.btn_Save_Address_Alert_Cancel");


            }

            _iwebstep.GetService().GivenUserClicksOn("REDEEMPRIZES.POINTS_REDEEM_BUTTON");
            _iwebstep.GetService().ThenUserWaits("5");

            if (functionauthCheck == "Y")
            {
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_PASSWORD_REDEEMPRIZE");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_RedeemPrize_data["reason"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_REASON_REDEEMPRIZE", "visibletext");
                _iwebstep.GetService().GivenUserEntersText(_RedeemPrize_data["comment"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_COMMENT_REDEEMPRIZE");
                _iwebstep.GetService().GivenUserClicksOn("AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_REDEEMPRIZE_OK");

            }
            _iwebstep.GetService().ThenUserWaits("5");
            _iwebstep.GetService().GivenUserClicksOn("REDEEMPRIZES.Redeem_Lable_Cancle");
        }

        [When(@"Loyalty User add a player ""(.*)"" as blacklist ""(.*)"" to a Event ""(.*)""")]
        private void AddPlayertoevent(string PlayerID, string blacklist, string eventname)
        {
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONFIGURATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("CONFIGURATION_SUB_NAV_BOX.EVENT_MANAGEMENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.CONFIGURE_EVENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.txt_SearchEventName");
            _iwebstep.GetService().GivenUserEntersText(eventname, "EVENT_MANAGEMENT_SUB_NAV_BOX.txt_SearchEventName");
            _iwebstep.GetService().WhenUserPressKey("Enter");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.txt_ClickSearchedEvent");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.LIST_LINK");
            _iwebstep.GetService().ThenUserWaits("4");

            if (blacklist.Equals("Y"))
            {
                _iwebstep.GetService().GivenUserEntersText(PlayerID, "EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_PLAYERID_TEXTBOX");
                _iwebstep.GetService().GivenUserEntersText(PlayerID, "EVENT_MANAGEMENT_SUB_NAV_BOX.chk_MarkPlayer_Blacklist");
                _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_PLAYERID_BUTTON");
            }
            else
            {
                _iwebstep.GetService().GivenUserEntersText(PlayerID, "EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_PLAYERID_TEXTBOX");
                _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.ADD_PLAYERID_BUTTON");

            }


        }

        [When(@"Loyalty player ""(.*)"" Return Redeemed Prize ""(.*)"" of a Event ""(.*)""")]

        private void returnprize(string PlayerID, string prizename, string eventname, Table datatables)
        /* fulfimentype
         * fulfilmentstatus 
         */
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            _ReturnPrize_data = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONFIGURATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("CONFIGURATION_SUB_NAV_BOX.EVENT_MANAGEMENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EVENT_MANAGEMENT_SUB_NAV_BOX.lnkReturnPrize");
            _iwebstep.GetService().GivenUserEntersText(PlayerID, "REDEEMPRIZES.REDEEM_PLAYERID");
            _iwebstep.GetService().GivenUserClicksOn("REDEEMPRIZES.FINDPLAYER_BUTTON");
            _iwebstep.GetService().ThenUserWaits("5");
            _iwebstep.GetService().GivenUserClicksOn("REDEEMPRIZES.REDEEMABLEEVENTS_GRID");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GetService().GivenUserVerifyAttribute("text", prizename, "RETURN_PRIZE.lbl_PrizeName");
            //if user want to verify functionalty of buttons of status update and type

            if (_ReturnPrize_data["fulfimentype"] != null || _ReturnPrize_data["fulfilmentstatus"] != null)
            {
                _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.chk_Prize");
                switch (_ReturnPrize_data["fulfimentype"])
                {
                    case "PickUp":
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.lbl_updatetopickup");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", "Fulfillment Type Updated successfully", "RETURN_PRIZE.lbl_AlertMessage");
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_cancelAlert");
                        break;
                    case "DropShip":
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.lbl_updatetodropship");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", "Fulfillment Type Updated successfully", "RETURN_PRIZE.lbl_AlertMessage");
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_cancelAlert");
                        break;
                    default:

                        break;
                }
                switch (_ReturnPrize_data["fulfilmentstatus"])
                {
                    case "Fulfilled":
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.chk_Prize");
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_updatetofulfilled");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", "Fulfillment Status Updated successfully", "RETURN_PRIZE.lbl_AlertMessage");
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_cancelAlert");
                        break;
                    case "Unfulfilled":
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.chk_Prize");
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.lbl_updatetoUnfulfilled");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", "Fulfillment Status Updated successfully", "RETURN_PRIZE.lbl_AlertMessage");
                        _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_cancelAlert");
                        break;
                    default:
                        break;

                }

                _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_PrintPrizeList");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_ClosePrintPDFPopup");
                _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_ReturnPrize");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserVerifyAttribute("text", "Prize Returned Successfully.", "RETURN_PRIZE.lbl_AlertMessage");
                _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_cancelAlert");

            }
            else
            {
                _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.chk_Prize");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_ReturnPrize");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserVerifyAttribute("text", "Prize Returned Successfully.", "RETURN_PRIZE.lbl_AlertMessage");
                _iwebstep.GetService().GivenUserClicksOn("RETURN_PRIZE.btn_cancelAlert");
            }
        }

    }
}
