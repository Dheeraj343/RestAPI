﻿using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.WebAbstraction;
using Automation.Framework.Exceptions;
using AventStack.ExtentReports.Gherkin.Model;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty
{
    [Binding]
    public class CompManagement : LoyaltyBase
    {
        ITestStepBuilder _iteststepbuilder;
        ITestStep _iteststep;
        IWebStepDef _iwebstep;
        ITestBaseManager _itestbasemanager;

        Dictionary<string, string> Outletdetails = new Dictionary<string, string>();
        Dictionary<string, string> Compdetails = new Dictionary<string, string>();
        Dictionary<string, string> IssueCompDetails = new Dictionary<string, string>();

        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();
            _itestbasemanager = Cucumber._serviceprovider.GetService<ITestBaseManager>();
        }
        [Given(@"EB user create Outlet ""(.*)"" with parameters")]
        public void GivenEBUserCreateOutletwithParameters(String outletname, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            Outletdetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserEntersText("Manage Comp", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().GivenUserClicksOn("EB_CONFIG_SUB_NAV.MANAGE_COMP_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.ManageOutletTab");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Add");
            _iwebstep.GetService().GivenUserEntersText(outletname, "EB_MANAGE_COMP.OutletName");
            _iwebstep.GetService().GivenUserGeneratesValue("uniquestring", "This 'Outlet' " + outletname + " is created using Automation :3", "description");
            _iwebstep.GetService().GivenUserEntersText("<$description$>", "EB_MANAGE_COMP.OutletDescription");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Outlet_property");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("EB_MANAGE_COMP.dropdownOption", ConvertStringtoTable("option:" + Outletdetails["property"]));
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Outlet_outletType");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("EB_MANAGE_COMP.dropdownOption", ConvertStringtoTable("option:" + Outletdetails["outlet type"]));
            //Setting a numeric value as POSID.
            String sql1 = "Select Top 1 POSID from UC_X_Outlet where ISNUMERIC(POSID)=1 order by OutletID DESC";
            String dbconnectionstring = "<#Halo_db_connectionstring#>";
            _iwebstep.GetService().GivenUserRunsQuery(sql1, dbconnectionstring, "DBPOSID");
            _iwebstep.GetService().GivenUserSavesArithmeticOperationsValue("numberadd", "<$DBPOSID$>", "1", "POSID");
             _iwebstep.GetService().GivenUserEntersText("<$POSID$>", "EB_MANAGE_COMP.OutletPOSID");
             _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Outlet_OutletForm");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("EB_MANAGE_COMP.dropdownOption", ConvertStringtoTable("option:" + Outletdetails["form"]));
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserGeneratesValue("uniquestring", "\\Automation\\ABC:3", "path");
	     _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Outlet_Addprinter");
	     _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("<$path$>", "EB_MANAGE_COMP.Outlet_printerpath");
	    _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Outlet_printerPopupAdd");
            _iwebstep.GetService().ThenUserWaits("2");
            if (Outletdetails.ContainsKey("auto settle comps"))
            {
                if (Outletdetails["auto settle comps"].Contains("checks"))
                {
                    _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.OutletAutoSettle");
                }
            }
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Outlet_save");
            _iwebstep.GetService().VerifyTextOnTheScreen("Outlet Saved");
            //Verifying created Outlet in DB.
            String sql = "Select Count(O.OutletID) from Dbo.UC_X_Outlet O Inner Join dbo.UC_X_Property P on P.PropertyID=O.PropertyID Where O.OutletName='" + outletname + "' AND P.PropertyName='" + Outletdetails["property"] + "'";
            _iwebstep.GetService().GivenUserRunsQuery(sql, dbconnectionstring, "DBOutletCount");
            _iwebstep.GetService().GivenUserPerformOperations("numberEquals", "1", "<$DBOutletCount$>");

        }

        [Given(@"EB user create Comp Item ""(.*)"" with parameters")]
        public void GivenEBUserCreateCompItemwithParameter(String Compname, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            Compdetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().WhenUserPerformActionBrowser("refresh");
            _iwebstep.GetService().GivenUserEntersText("Manage Comp", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().GivenUserClicksOn("EB_CONFIG_SUB_NAV.MANAGE_COMP_LINK");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Manage_Comp_Items");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.CompItemAdd");
            _iwebstep.GetService().GivenUserEntersText(Compname, "EB_MANAGE_COMP.CompItem_Name");
            _iwebstep.GetService().GivenUserGeneratesValue("uniquestring", "This Comp Item '" + Compname + "' is created using Automation :3", "description");
            _iwebstep.GetService().GivenUserEntersText("<$description$>", "EB_MANAGE_COMP.CompItem_Desc");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(Compdetails["outlet"], "EB_MANAGE_COMP.Comp_Outlet", "visibletext");
            _iwebstep.GetService().GivenUserEntersText(Compdetails["customer comp value"], "EB_MANAGE_COMP.Customer_CompValue");
            _iwebstep.GetService().GivenUserEntersText(Compdetails["internal comp value"], "EB_MANAGE_COMP.Internal_CompValue");
            _iwebstep.GetService().GivenUserEntersText(Compdetails["bucketview"], "EB_MANAGE_COMP.CompItem_BucketSearch");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("EB_MANAGE_COMP.dropdownOption", ConvertStringtoTable("option:" + Compdetails["bucketview"]));
            //verify number of comp Item with same name before saving this Comp Item.
            //Verifying created Outlet in DD if aleardy Exist with same name.
            String sql = "Select count(c.CompItemID) from UC_X_CompItem C Inner Join UC_X_Outlet o On c.OutletID=o.OutletID where c.CompName='" + Compname + "'";
            String dbconnectionstring = "<#Halo_db_connectionstring#>";
            _iwebstep.GetService().GivenUserRunsQuery(sql, dbconnectionstring, "beforecompCount");
            _iwebstep.GetService().GivenUserClicksOn("EB_MANAGE_COMP.Comp_Save");
            //Validating comp In list on UI.
            _iwebstep.GetService().ThenUserVerifyAllListOptions("EB_MANAGE_COMP.CompList", Compname);
            //Validating a new comp added in DB with Comp Name.
            _iwebstep.GetService().GivenUserSavesArithmeticOperationsValue("numberadd", "<$beforecompCount$>", "1", "finalcompcount");
            _iwebstep.GetService().GivenUserRunsQuery(sql, dbconnectionstring, "aftercompCount");
            _iwebstep.GetService().GivenUserPerformOperations("numberEquals", "<$finalcompcount$>", "<$aftercompCount$>");
            //Setting Comp Limit by Outlet & Authorizing the Outlet.
            _iwebstep.GetService().GivenUserEntersText("Player Transaction Limits", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYERTRANSACTIONSLIMIT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_TRANS_LIMITS.tabComplimitbyoutlet");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy("UC_Admin", "USER_GROUP_PERMISSIONS.USER_GROUP_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_TRANS_LIMITS.SELECT_BUCKET");
            _iwebstep.GetService().GivenUserEntersText(Compdetails["bucketview"], "PLAYER_TRANS_LIMITS.CompLimitbucketSearch");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("PLAYER_TRANS_LIMITS.drodpdownOption", ConvertStringtoTable("option:" + Compdetails["bucketview"]));
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("1000", "PLAYER_TRANS_LIMITS.txtMaxLimitPerTransaction");
            _iwebstep.GetService().GivenUserEntersText("1000", "PLAYER_TRANS_LIMITS.txtMaxLimitPerUser");
            _iwebstep.GetService().GivenUserEntersText("1000", "PLAYER_TRANS_LIMITS.txtMaxLimitPerGuest");
            if (Compdetails.ContainsKey("negative complimit"))
            {
                _iwebstep.GetService().GivenUserEntersText(Compdetails["negative complimit"], "PLAYER_TRANS_LIMITS.NegativeCompIssuLimit");
            }
            if (!Compdetails.ContainsKey("outlet authorization"))
            {
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_TRANS_LIMITS.txtOutletsNotAuthorized");
                _iwebstep.GetService().GivenUserEntersText(Compdetails["outlet"], "PLAYER_TRANS_LIMITS.txtOutletsNotAuthorized");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(Compdetails["outlet"], "PLAYER_TRANS_LIMITS.SelectnotAuthorizeOutlet", "visibletext");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserClicksOn("PLAYER_TRANS_LIMITS.Outlet_AddRight");
                _iwebstep.GetService().ThenUserWaits("2");
            }
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_TRANS_LIMITS.Savebtn");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_TRANS_LIMITS.Savebtn");
            _iwebstep.GetService().VerifyTextOnTheScreen("Information Saved!");

        }

        [Given(@"EB user Issue Comp with Function Authorization ""(.*)"" with parameters")]
        public void GivenEbUserIssueCompWithParameters(String authorization, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            IssueCompDetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_INFO.ISSUE_COMP_BUTTON");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserSwitchesToFrame("ISSUE_COMP.ISSUE_COMP_FRAME");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(IssueCompDetails["comp type"], "ISSUE_COMP.COMP_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(IssueCompDetails["property"], "ISSUE_COMP.COMP_PROPERTY_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(IssueCompDetails["outlet"], "ISSUE_COMP.COMP_OUTLET_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(IssueCompDetails["bucketview"], "ISSUE_COMP.COMP_BUCKET_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(IssueCompDetails["comp item"], "ISSUE_COMP.COMP_ITEM_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().WhenUserClears("ISSUE_COMP.COMP_COUNT_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserEntersText(IssueCompDetails["comp count"], "ISSUE_COMP.COMP_COUNT_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ISSUE_COMP.COMP_ISSUEDATE_TEXTBOX");
            if (IssueCompDetails.ContainsKey("issued date"))
            {
                _iwebstep.GetService().WhenUserClears("ISSUE_COMP.COMP_ISSUEDATE_TEXTBOX");
                _iwebstep.GetService().GivenUserEntersText(IssueCompDetails["issued date"], "ISSUE_COMP.COMP_ISSUEDATE_TEXTBOX");
            }
            if (authorization == "Y")
            {
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "ISSUE_COMP.PASSWORD_TEXTBOX");
                _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(IssueCompDetails["reason"], "ISSUE_COMP.ISSUE_COMP_REASON", "visibletext");
                _iwebstep.GetService().GivenUserEntersText(IssueCompDetails["comment"], "ISSUE_COMP.COMMENT_TEXTBOX");

            }
            _iwebstep.GetService().GivenUserClicksOn("ISSUE_COMP.ISSUE_COMP_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ISSUE_COMP.btnOk");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            
        }
    }

}


