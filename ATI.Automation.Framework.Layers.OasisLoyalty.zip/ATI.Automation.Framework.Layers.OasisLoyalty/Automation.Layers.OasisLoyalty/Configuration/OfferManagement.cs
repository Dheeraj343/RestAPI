﻿using Automation.Framework.Core.Common.CommonAbstraction;
using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.Steps;
using Automation.Framework.Core.Web.Test.Base;
using Automation.Framework.Core.Web.UiObject;
using Automation.Framework.Core.Web.WebAbstraction;
using ExcelDataReader.Log;
using Microsoft.Extensions.DependencyInjection;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;
using ILog = Automation.Framework.Core.Common.CommonAbstraction.ILog;

namespace Automation.Layers.OasisLoyalty
{

    // This will hold all step definitions of Web related to Enrollment.
    [Binding]
    public class OfferManagement : LoyaltyBase
    {

        IWebStepDef _iwebstep;
        ITestStepBuilder _iteststepbuilder;
        ITestBaseManager _itestbasemanager;
        ITestStep _iteststep;
        ILog _ilog;

        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _ilog = Cucumber._serviceprovider.GetService<ILog>();
            _itestbasemanager = Cucumber._serviceprovider.GetService<ITestBaseManager>();
        }


        [When(@"Loyalty user create program type ""(.*)"" by using subtype ""(.*)""")]
        private void WhenUserCreateProgramType(String programtype,String subtype)
        {
            _iteststep = _iteststepbuilder.SetParams(programtype, subtype).Build();            
            _iwebstep.GetService().GivenUserEntersText("Manage Offer Programs", "MAIN_NAV_BOX.EB_MenuSearch");
            _ilog.Information("Entered Manage offer Programs");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("lylMAIN_NAV_BOX.mnu_Manage_offer_program");
            _iwebstep.GetService().GivenUserClicksOn("lylMAIN_NAV_BOX.mnu_Manage_offer_program");
            _ilog.Information("Clicked on lylMAIN_NAV_BOX.mnu_Manage_offer_program");
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_ProgramType.btn_Add_Program_Type");
            _ilog.Information("Clicked on lylOffer_ProgramType.btn_Add_Program_Type");
            _iwebstep.GetService().GivenUserEntersText(_iteststep.GetParameters()[0], "lylOffer_ProgramType.txt_ProgramType_Name");
            _ilog.Information("Entered text {0} on lylOffer_ProgramType.txt_ProgramType_Name", _iteststep.GetParameters()[0]);
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_ProgramType.btnSave");
            _ilog.Information("Clicked on lylOffer_ProgramType.btnSave");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", "Record inserted successfully", "lylOffer_ProgramType.lbl_ProgramType/Subtype_SuccessMsg");
            _iwebstep.GetService().WhenUserClears("lylOffer_ProgramType.txt_Search_Box");
            _iwebstep.GetService().GivenUserEntersText(_iteststep.GetParameters()[0], "lylOffer_ProgramType.txt_Search_Box");
            _ilog.Information("Entered text {0} on lylOffer_ProgramType.txt_Search_Box", _iteststep.GetParameters()[0]);
            _iwebstep.GetService().WhenUserPressKey("enter");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(_iteststep.GetParameters()[0], "lylOffer_ProgramType.mnu_OfferProgramFilter", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_ProgramType.btn_Add_Subtypes");
            _ilog.Information("Clicked on lylOffer_ProgramType.btn_Add_Subtypes");
            _iwebstep.GetService().GivenUserEntersText(_iteststep.GetParameters()[1], "lylOffer_ProgramType.Subtype_Name");
            _ilog.Information("Entered text {0} on lylOffer_ProgramType.Subtype_Name", _iteststep.GetParameters()[1]);
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_ProgramType.btn_Save_Subtypes");
            _ilog.Information("Clicked on lylOffer_ProgramType.btn_Save_Subtypes");
            Table table = new Table(new string[] { "Key", "Value" });
            table.AddRow(new string[] { "SubTypeName", _iteststep.GetParameters()[1] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("lylOffer_ProgramType.tbl_SubType_Filter", "true", table);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("lylOffer_ProgramType.tbl_SubType_Filter", table);
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_ProgramType.btnSave");
            _ilog.Information("Clicked on lylOffer_ProgramType.btnSave");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", "Record updated successfully", "lylOffer_ProgramType.lbl_ProgramType/Subtype_SuccessMsg");
        }


        [When(@"Loyalty user create offer type with data")]
        private void WhenUserCreateOfferType(Table table)
        {            
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            Dictionary<string, string> data = _iteststep.GetMultiRowDataTable()[0];            
            _iwebstep.GetService().GivenUserEntersText("Manage Offer Type", "MAIN_NAV_BOX.EB_MenuSearch");
            _ilog.Information("Entered text Manage Offer Type on MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().GivenUserClicksOn("lylMAIN_NAV_BOX.mnu_Manage_Offer_type");
            _ilog.Information("Clicked on lylMAIN_NAV_BOX.mnu_Manage_Offer_type");
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_Types.btnAdd_Offer_Type");
            _ilog.Information("Clicked on lylOffer_Types.btnAdd_Offer_Type");
            _iwebstep.GetService().GivenUserEntersText(data["offertype"], "lylOffer_Types.txt_Offertype_Name");
            _ilog.Information("Entered text {0} on lylOffer_Types.txt_Offertype_Name", data["offertype"]);
            _iwebstep.GetService().WhenUserClears("lylOffer_Types.txt_Offer_Code");
            _iwebstep.GetService().GivenUserEntersText(data["offercode"], "lylOffer_Types.txt_Offer_Code");
            _ilog.Information("Entered text {0} on lylOffer_Types.txt_Offer_Code", data["offercode"]);
            if (data["active"].ToLower().Equals("false"))
            {
                _iwebstep.GetService().ThenUserElement("deselects", "lylOffer_Types.chk_Active");
            }            
            if (data["redeemable"].ToLower().Equals("false"))
            {
                _iwebstep.GetService().ThenUserElement("deselects", "lylOffer_Types.chk_Is_Redemable");
            }
            _iwebstep.GetService().GivenUserEntersText(data["offercode"], "lylOffer_Types.txt_Offer_Code");
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_Types.btn_Save_Offer_Type");
            _ilog.Information("Clicked on lylOffer_Types.btn_Save_Offer_Type");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", "Record inserted successfully", "lylOffer_Types.lbl_ErrorMessage");
            _iwebstep.GetService().WhenUserClears("lylOffer_Types.txt_Search_OfferType");
            _iwebstep.GetService().GivenUserEntersText(data["offertype"], "lylOffer_Types.txt_Search_OfferType");
            _ilog.Information("Entered text {0} on lylOffer_Types.txt_Search_OfferType", data["offertype"]);
            _iwebstep.GetService().WhenUserPressKey("enter");
            Table table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "OfferType", data["offertype"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("lylOffer_Types.Drop_OfferTypeValue", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("lylOffer_Types.Drop_OfferTypeValue", table1);
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_Types.btn_Add_OfferSubtypes");
            _ilog.Information("Clicked on lylOffer_Types.btn_Add_OfferSubtypes");
            _iwebstep.GetService().GivenUserEntersText(data["offersubtype"], "lylOffer_Types.txtOfferSubtype_Name");
            _iwebstep.GetService().GivenUserEntersText(data["offersubtypecode"], "lylOffer_Types.txt_Subtypes_Code");
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_Types.btnSave_Subtypes");
            _ilog.Information("Clicked on lylOffer_Types.btnSave_Subtypes");
            table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "SubtypeName", data["offersubtype"] });
            table1.AddRow(new string[] { "SubtypeCode", data["offersubtypecode"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("lylOffer_Types.Table_SubType_Row", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("lylOffer_Types.Table_SubType_Row", table1);
            _iwebstep.GetService().GivenUserClicksOn("lylOffer_Types.btn_Save_Offer_Type");
            _ilog.Information("Clicked on lylOffer_Types.btn_Save_Offer_Type");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", "Record updated successfully", "lylOffer_Types.lbl_ErrorMessage");
        }


        [When(@"Loyalty user create offer disclaimer with data")]
        private void WhenUserCreateOfferDisclaimer(Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            Dictionary<string, string> data = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserEntersText("Offer Disclaimer", "MAIN_NAV_BOX.EB_MenuSearch");
            _ilog.Information("Entered text Offer Disclaimer on MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().GivenUserClicksOn("lylMAIN_NAV_BOX.Offer_Disclaimer");
            _ilog.Information("Clicked on lylMAIN_NAV_BOX.Offer_Disclaimer");
            _iwebstep.GetService().VerifyTextOnTheScreen("Offer Disclaimers");
            _iwebstep.GetService().GivenUserClicksOn("lylOFFERDISCLAIMERS.btnADDDISCLAIMER");
            _ilog.Information("Clicked on lylOFFERDISCLAIMERS.btnADDDISCLAIMER");
            _iwebstep.GetService().GivenUserEntersText(data["disclaimername"], "lylOFFERDISCLAIMERS.txtDIsclaimerName");
            _ilog.Information("Entered text {0} on lylOFFERDISCLAIMERS.txtDIsclaimerName", data["disclaimername"]);
            _iwebstep.GetService().GivenUserClicksOn("lylOFFERDISCLAIMERS.Dropdown_OfferType");
            _ilog.Information("Clicked on lylOFFERDISCLAIMERS.Dropdown_OfferType");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["offertype"], "lylOFFERDISCLAIMERS.Dropdown_OfferType", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("lylOFFERDISCLAIMERS.Offer_Sub_type");
            _ilog.Information("Clicked on lylOFFERDISCLAIMERS.Offer_Sub_type");
            Table table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "OfferSubTypeName", data["offersubtype"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("lylOFFERDISCLAIMERS.OfferSubType_DropDownList", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("lylOFFERDISCLAIMERS.OfferSubType_DropDownList", table1);
            _iwebstep.GetService().GivenUserClicksOn("lylOFFERDISCLAIMERS.Property_Name");
            _ilog.Information("Clicked on lylOFFERDISCLAIMERS.Property_Name");
            table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "Property", data["propertyname"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("lylOFFERDISCLAIMERS.DropDown_PropertyList", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("lylOFFERDISCLAIMERS.DropDown_PropertyList", table1);
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["disclaimer"], "lylOFFERDISCLAIMERS.Offer_Disclaimer_dropdown", "visibletext");
            _ilog.Information("Selected item {0} from lylOFFERDISCLAIMERS.Offer_Disclaimer_dropdown", data["disclaimer"]);
            _iwebstep.GetService().GivenUserClicksOn("lylOFFERDISCLAIMERS.btn_Disclaimer_Submit");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("lylOFFERDISCLAIMERS.btn_Save_DIsclaimer");
            _ilog.Information("Clicked on lylOFFERDISCLAIMERS.btn_Save_DIsclaimer");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", "Record inserted successfully", "lylOFFERDISCLAIMERS.lbl_ErrorMessage");
        }


        [When(@"Loyalty user create campaign with data")]
        private void WhenUserCreateCampaign(Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            Dictionary<string, string> data = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserEntersText("Manage Campaign", "MAIN_NAV_BOX.EB_MenuSearch");
            _ilog.Information("Entered text Manage Campaign on MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().GivenUserClicksOn("lylMAIN_NAV_BOX.Campaign_Manage");
            _ilog.Information("Clicked on lylMAIN_NAV_BOX.Campaign_Manage");
            _iwebstep.GetService().VerifyTextOnTheScreen("Campaign Management");
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.btn_Campaign_Add");
            _ilog.Information("Clicked on ltyCampaign_Manage.btn_Campaign_Add");
            _iwebstep.GetService().VerifyTextOnTheScreen("Campaign - New");
            _iwebstep.GetService().GivenUserEntersText(data["campaignname"], "ltyCampaign_Manage.txt_Campaign_Name");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Campaign_Name", data["campaignname"]);
            _iwebstep.GetService().GivenUserEntersText(data["campaigncode"], "ltyCampaign_Manage.txt_Campaign_Code");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Campaign_Code", data["campaigncode"]);
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["programtype"], "ltyCampaign_Manage.txt_Program_Type", "visibletext");
            _ilog.Information("Selected item {0} from ltyCampaign_Manage.txt_Program_Type", data["programtype"]);
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["programsubtype"], "ltyCampaign_Manage.txt_Program_SubType", "visibletext");
            _ilog.Information("Selected item {0} from ltyCampaign_Manage.txt_Program_SubType", data["programsubtype"]);
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtStartDate').setAttribute('value', '"+ data["startdate"] + "')");
            _ilog.Information("Entered text {0} on ctl00_ContentPlaceHolder1_txtStartDate", data["startdate"]);
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtEndDate').setAttribute('value', '" + data["enddate"] + "')");
            _ilog.Information("Entered text {0} on ctl00_ContentPlaceHolder1_txtEndDate", data["enddate"]);
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.txt_Start_Time");
            _ilog.Information("Clicked on ltyCampaign_Manage.txt_Start_Time");
            _iwebstep.GetService().GivenUserEntersText(data["starttime"], "ltyCampaign_Manage.txt_Start_Time");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Start_Time", data["starttime"]);
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.txt_Start_Time");
            _iwebstep.GetService().GivenUserEntersText(data["visibledays"], "ltyCampaign_Manage.txt_Visible_Before_Days");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Visible_Before_Days", data["visibledays"]);
            _iwebstep.GetService().GivenUserEntersText(data["endtime"], "ltyCampaign_Manage.txt_End_Time");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_End_Time", data["endtime"]);
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["remindertype"], "ltyCampaign_Manage.DropDown_Reminder_Type", "visibletext");
            _ilog.Information("Selected item {0} from ltyCampaign_Manage.DropDown_Reminder_Type", data["remindertype"]);
            if (data["distributiontype"].ToLower().Equals("text"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyCampaign_Manage.chk_Text_DistributionChannel");
            }
            else if(data["distributiontype"].ToLower().Equals("email"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyCampaign_Manage.chk_Email_DistributionChannel");
            }
            else if (data["distributiontype"].ToLower().Equals("direct mail"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyCampaign_Manage.chk_DirectMail_DistributionChannel");
            }
            else if (data["distributiontype"].ToLower().Equals("casino"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyCampaign_Manage.chk_Casino_DistributionChannel");
            }
            _iwebstep.GetService().GivenUserEntersText(data["budget"], "ltyCampaign_Manage.txt_Budget_Allocated");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Budget_Allocated", data["budget"]);
            _iwebstep.GetService().GivenUserEntersText(data["revenue"], "ltyCampaign_Manage.txt_Estimated_Revenue");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Estimated_Revenue", data["revenue"]);
            _iwebstep.GetService().GivenUserEntersText(data["overheadperday"], "ltyCampaign_Manage.txt_OverHead_PerDay");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_OverHead_PerDay", data["overheadperday"]);
            _iwebstep.GetService().GivenUserEntersText(data["printperpiece"], "ltyCampaign_Manage.txt_Print_PerPiece");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Print_PerPiece", data["printperpiece"]);
            _iwebstep.GetService().GivenUserEntersText(data["postageperpiece"], "ltyCampaign_Manage.txt_Postage_PerPiece");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Postage_PerPiece", data["postageperpiece"]);
            _iwebstep.GetService().GivenUserEntersText(data["gamingtextrate"], "ltyCampaign_Manage.txt_Gaming_Text_Rate");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Gaming_Text_Rate", data["gamingtextrate"]);
            _iwebstep.GetService().GivenUserEntersText(data["miscellaneouscost"], "ltyCampaign_Manage.txt_Miscellaneous_Costs");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.txt_Miscellaneous_Costs", data["miscellaneouscost"]);
            _iwebstep.GetService().GivenUserEntersText("Automation Notes", "ltyCampaign_Manage.txt_Notes");            
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.btn_Save_Campaign");
            _ilog.Information("Clicked on ltyCampaign_Manage.btn_Save_Campaign");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", "The changes has been successfully saved.", "ltyCampaign_Manage.Popup_ManageCampaign_Successful");
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.btn_OK_ManageCampaing_Popup");
            _ilog.Information("Clicked on ltyCampaign_Manage.btn_OK_ManageCampaing_Popup");
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.lbl_Campaigns_Label");
            _ilog.Information("Clicked on ltyCampaign_Manage.lbl_Campaigns_Label");
            _iwebstep.GetService().GivenUserEntersText(data["campaignname"], "ltyCampaign_Manage.SearchFilter_CampaignName");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.SearchFilter_CampaignName", data["campaignname"]);
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.btn_Search_Campaign");
            _ilog.Information("Clicked on ltyCampaign_Manage.btn_Search_Campaign");
            Table table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "Campaign", data["campaignname"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("ltyCampaign_Manage.tbl_Campaign_List", "true", table1);            
         
        }

        [When(@"Loyalty user create segment with data")]
        private void WhenUserCreateSegment(Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            Dictionary<string, string> data = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserEntersText("Manage Campaign", "MAIN_NAV_BOX.EB_MenuSearch");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.SearchFilter_CampaignName", "Manage Campaign");
            _iwebstep.GetService().GivenUserClicksOn("lylMAIN_NAV_BOX.Campaign_Manage");
            _ilog.Information("Clicked on lylMAIN_NAV_BOX.Campaign_Manage");
            _iwebstep.GetService().VerifyTextOnTheScreen("Campaign Management");
            Table table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "Campaign", data["campaignname"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("ltyCampaign_Manage.tbl_Campaign_List", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("ltyCampaign_Manage.tbl_Campaign_List", table1);
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("ltyCampaign_Manage.btn_View_Segment");
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.btn_View_Segment");
            _ilog.Information("Clicked on ltyCampaign_Manage.btn_View_Segment");
            _iwebstep.GetService().ThenUserVerifiesElement("ltyManage_Segment.lbl_Manage_Segment_PageTitle", "true");
            _iwebstep.GetService().GivenUserClicksOn("ltyManage_Segment.btn_Add_Segment");
            _ilog.Information("Clicked on ltyCampaign_Manage.btn_Add_Segment");
            _iwebstep.GetService().GivenUserEntersText(data["segmentname"], "ltyManage_Segment.txt_Segment_Name");
            _ilog.Information("Entered text {0} on ltyManage_Segment.txt_Segment_Name", data["segmentname"]);
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["segmentstatus"], "ltyManage_Segment.DropDown_Status", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("ltyManage_Segment.Save_Button");
            _ilog.Information("Clicked on ltyManage_Segment.Save_Button");
            _iwebstep.GetService().VerifyTextOnTheScreen("The changes have been successfully saved.");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserPerformActionBrowser("refresh");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserClears("ltyManage_Segment.Filter_Segment_Name");
            _iwebstep.GetService().GivenUserEntersText(data["segmentname"], "ltyManage_Segment.Filter_Segment_Name");
            _ilog.Information("Entered text {0} on ltyManage_Segment.Filter_Segment_Name", data["segmentname"]);
            _iwebstep.GetService().GivenUserClicksOn("ltyManage_Segment.btn_Search");
            _ilog.Information("Clicked on ltyManage_Segment.btn_Search");
            table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "SegmentName", data["segmentname"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("ltyManage_Segment.tbl_Segment_List", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("ltyManage_Segment.tbl_Segment_List", table1);
        }

        [When(@"Loyalty user create offer with data")]
        private void WhenUserCreateOfferSegment(Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            Dictionary<string, string> data = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserEntersText("Manage Campaign", "MAIN_NAV_BOX.EB_MenuSearch");
            _ilog.Information("Entered text {0} on ltyCampaign_Manage.SearchFilter_CampaignName", "Manage Campaign");
            _iwebstep.GetService().GivenUserClicksOn("lylMAIN_NAV_BOX.Campaign_Manage");
            _ilog.Information("Clicked on lylMAIN_NAV_BOX.Campaign_Manage");
            _iwebstep.GetService().VerifyTextOnTheScreen("Campaign Management");
            Table table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "Campaign", data["campaignname"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("ltyCampaign_Manage.tbl_Campaign_List", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("ltyCampaign_Manage.tbl_Campaign_List", table1);
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("ltyCampaign_Manage.btn_View_Segment");
            _iwebstep.GetService().GivenUserClicksOn("ltyCampaign_Manage.btn_View_Segment");
            _ilog.Information("Clicked on ltyCampaign_Manage.btn_View_Segment");
            _iwebstep.GetService().WhenUserClears("ltyManage_Segment.Filter_Segment_Name");
            _iwebstep.GetService().GivenUserEntersText(data["segmentname"], "ltyManage_Segment.Filter_Segment_Name");
            _ilog.Information("Entered text {0} on ltyManage_Segment.Filter_Segment_Name", data["segmentname"]);
            _iwebstep.GetService().GivenUserClicksOn("ltyManage_Segment.btn_Search");
            _ilog.Information("Clicked on ltyManage_Segment.btn_Search");
            table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "SegmentName", data["segmentname"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("ltyManage_Segment.tbl_Segment_List", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("ltyManage_Segment.tbl_Segment_List", table1);
            _iwebstep.GetService().GivenUserClicksOn("ltyManage_Segment.btn_View_Offers");
            _ilog.Information("Clicked on ltyCampaign_Manage.btn_View_Offers");
            _iwebstep.GetService().GivenUserClicksOn("ltyMaster_Offers.lnk_Add_Offers");
            _ilog.Information("Clicked on ltyMaster_Offers.lnk_Add_Offers");
            _iwebstep.GetService().GivenUserEntersText(data["offername"], "ltyMaster_Offers.txt_Offer_Name");
            _ilog.Information("Entered text {0} on ltyMaster_Offers.txt_Offer_Name", data["offername"]);
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["offerstatus"], "ltyMaster_Offers.Status_DropDown", "visibletext");
            _ilog.Information("Selected item {0} from ltyMaster_Offers.Status_DropDown", data["offerstatus"]);
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["property"], "ltyMaster_Offers.DropDown_Property", "visibletext");
            _ilog.Information("Selected item {0} from ltyMaster_Offers.DropDown_Property", data["property"]);
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["offertype"], "ltyMaster_Offers.OfferType_DropDown", "visibletext");
            _ilog.Information("Selected item {0} from ltyMaster_Offers.OfferType_DropDown", data["offertype"]);
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["offersubtype"], "ltyMaster_Offers.OfferSubType_DropDown", "visibletext");
            _ilog.Information("Selected item {0} from ltyMaster_Offers.OfferSubType_DropDown", data["offersubtype"]);
            _iwebstep.GetService().GivenUserEntersText(data["offeramount"], "ltyMaster_Offers.txt_Offer_Amount");
            _ilog.Information("Entered text {0} on ltyMaster_Offers.txt_Offer_Amount", data["offeramount"]);
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtStartDate').setAttribute('value', '" + data["startdate"] + "')");
            _ilog.Information("Entered text {0} on ctl00_ContentPlaceHolder1_txtStartDate", data["startdate"]);
            _iwebstep.GetService().GivenUserEntersText(data["starttime"], "ltyMaster_Offers.txt_Start_Time");
            _ilog.Information("Entered text {0} on ltyMaster_Offers.txt_Start_Time", data["starttime"]);
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('ctl00_ContentPlaceHolder1_txtEndDate').setAttribute('value', '" + data["enddate"] + "')");
            _ilog.Information("Entered text {0} on ctl00_ContentPlaceHolder1_txtEndDate", data["enddate"]);
            _iwebstep.GetService().GivenUserEntersText(data["endtime"], "ltyMaster_Offers.txt_End_Time");
            _ilog.Information("Entered text {0} on ltyMaster_Offers.txt_End_Time", data["endtime"]);
            
            if (data["printable"].ToLower().Equals("true"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyMaster_Offers.chk_Printable");
            }
            if (data["reservable"].ToLower().Equals("true"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyMaster_Offers.chk_Reservable");
            }
            else if (data["partialredemption"].ToLower().Equals("true"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyMaster_Offers.chk_Partial_Redemption");
            }
            else if (data["private"].ToLower().Equals("true"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyMaster_Offers.chk_Private");
            }
            else if (data["kiosk"].ToLower().Equals("true"))
            {
                _iwebstep.GetService().ThenUserElement("selects", "ltyMaster_Offers.chkKiosk");
            }
            
            _iwebstep.GetService().GivenUserEntersText("Automation Test Description", "ltyMaster_Offers.txt_Description");
            _ilog.Information("Entered text {0} on ltyMaster_Offers.txt_Description", "Automation Test Description");
            _iwebstep.GetService().GivenUserEntersText("Automation Alternate Description", "ltyMaster_Offers.txt_Alternate_Description");
            _ilog.Information("Entered text {0} on ltyMaster_Offers.txt_Alternate_Description", "Automation Alternate Description");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(data["disclaimer"], "ltyMaster_Offers.Disclaimer_DropDown", "visibletext");
            _ilog.Information("Selected item {0} from ltyMaster_Offers.Disclaimer_DropDown", data["disclaimer"]);
            _iwebstep.GetService().GivenUserClicksOn("ltyMaster_Offers.Save_Button");
            _ilog.Information("Clicked on ltyMaster_Offers.Save_Button");
            _iwebstep.GetService().VerifyTextOnTheScreen("The changes have been successfully saved.");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserPerformActionBrowser("refresh");
            _iwebstep.GetService().ThenUserWaits("2");
            table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "SegmentName_Breadcrumb", data["segmentname"] });            
            _iwebstep.GetService().GivenUserClicksOnWithParameters("ltyMaster_Offers.SegmentName_Breadcrumb_Link", table1);
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ltyManage_Segment.btn_View_Offers");
            _ilog.Information("Clicked on ltyManage_Segment.btn_View_Offers");
            table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "offer", data["offername"] });
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("ltyMaster_Offers.tbl_Master_Offers_List", "true", table1);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("ltyMaster_Offers.tbl_Master_Offers_List", table1);
            
        }


        [When(@"Loyalty user ""(.*)"" offer ""(.*)"" of amount ""(.*)"" to player ""(.*)""")]
        private void WhenUserAssignOfferToPlayer(string action, string offer, string amount, string player)
        {
            _iteststep = _iteststepbuilder.SetParams(offer, player).Build();
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(_iteststep.GetParameters()[1], "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _ilog.Information("Entered text {0} on PLAYER_SEARCH.PLAYER_ID_TEXTBOX", _iteststep.GetParameters()[1]);
            _iwebstep.GetService().GivenUserClicksOn("OLW_DASHBOARD.btnplayersearch");
            _ilog.Information("Clicked on OLW_DASHBOARD.btnplayersearch");
            Table table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "Dashboard_Tab", "Offers" });
            _iwebstep.GetService().GivenUserClicksOnWithParameters("OLW_DASHBOARD.Dashboard_Tab", table1);
            table1 = new Table(new string[] { "Key", "Value" });
            table1.AddRow(new string[] { "OfferName", offer });
            table1.AddRow(new string[] { "OfferType", "" });
            table1.AddRow(new string[] { "StartDate", "" });
            table1.AddRow(new string[] { "EndDate", "" });
            if (action.ToLower().Equals("redeem")) {
                table1.AddRow(new string[] { "Amount", "" });
            }
            else {
                table1.AddRow(new string[] { "Amount", amount });
            }
            
            
            table1.AddRow(new string[] { "Property", "" });
            table1.AddRow(new string[] { "IsPrivate", "" });

            if (action.ToLower().Equals("assign"))
            {
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Add_Active_Offer");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_Add_Active_Offer");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserEntersText(_iteststep.GetParameters()[0], "OLW_PLAYER_OFFER.txt_OfferName_Search");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_OfferName_Search", _iteststep.GetParameters()[0]);
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Offers_Search");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_Offers_Search");

                _iwebstep.GetService().GivenUserClicksOnWithParameters("OLW_PLAYER_OFFER.lnkunassignedPrivateOffer", table1);
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_AddActiveOffer");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_AddActiveOffer");
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "OLW_PLAYER_OFFER.txt_Authorization_Password");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_OfferName_Search", "<#Halo_password#>");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Guest Satisfaction", "OLW_PLAYER_OFFER.txt_Authorization_Reason", "visibletext");
                _ilog.Information("Selected item {0} from ltyMaster_Offers.OfferSubType_DropDown", "Guest Satisfaction");
                _iwebstep.GetService().GivenUserEntersText("Test Comments", "OLW_PLAYER_OFFER.txt_Authorization_Comment");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_Authorization_Comment", "Test Comments");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Authorization_Submit");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_Authorization_Submit");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Information_Popup_OK");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_CancelAndReturn_PlayerOffer");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().WhenUserClears("OLW_PLAYER_OFFER.txt_OfferName_Search");
                _iwebstep.GetService().GivenUserEntersText(offer, "OLW_PLAYER_OFFER.txt_OfferName_Search");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_OfferName_Search", offer);
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _iwebstep.GetService().ThenUserWaits("2");
                table1.AddRow(new string[] { "Status", "Active" });
                _iwebstep.GetService().GivenUserClicksOnWithParameters("OLW_PLAYER_OFFER.lnkassignedprivateoffer", table1);
            }
            else if (action.ToLower().Equals("delete") || action.ToLower().Equals("reserve"))
            {
                _iwebstep.GetService().GivenUserEntersText(offer, "OLW_PLAYER_OFFER.txt_OfferName_Search");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_Authorization_Comment", offer);
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _iwebstep.GetService().ThenUserWaits("2");
                table1.AddRow(new string[] { "Status", "Active" });                

                _iwebstep.GetService().GivenUserClicksOnWithParameters("OLW_PLAYER_OFFER.lnkassignedprivateoffer", table1);
                if (action.ToLower().Equals("delete"))
                {
                    _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Delete_Offer");
                    _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_Delete_Offer");
                }
                else
                {
                    _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Reserve_Offer");
                    _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_Reserve_Offer");
                }
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "OLW_PLAYER_OFFER.txt_Authorization_Password");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_OfferName_Search", "<#Halo_password#>");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Guest Satisfaction", "OLW_PLAYER_OFFER.txt_Authorization_Reason", "visibletext");
                _ilog.Information("Selected item {0} from ltyMaster_Offers.OfferSubType_DropDown", "Guest Satisfaction");
                _iwebstep.GetService().GivenUserEntersText("Test Comments", "OLW_PLAYER_OFFER.txt_Authorization_Comment");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_Authorization_Comment", "Test Comments");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Authorization_Submit");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_Authorization_Submit");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Information_Popup_OK");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().WhenUserClears("OLW_PLAYER_OFFER.txt_OfferName_Search");
                _iwebstep.GetService().GivenUserEntersText(offer, "OLW_PLAYER_OFFER.txt_OfferName_Search");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_Authorization_Comment", offer);
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _iwebstep.GetService().ThenUserWaits("2");
                if (action.ToLower().Equals("reserve"))
                {
                    _iwebstep.GetService().ThenUserElement("selects", "OLW_PLAYER_OFFER.chk_Reserved");
                    _ilog.Information("Selected checkbox chk_Reserved");
                    table1 = new Table(new string[] { "Key", "Value" });
                    table1.AddRow(new string[] { "OfferName", offer });
                    table1.AddRow(new string[] { "OfferType", "" });
                    table1.AddRow(new string[] { "StartDate", "" });
                    table1.AddRow(new string[] { "EndDate", "" });
                    table1.AddRow(new string[] { "Amount", "" });
                    table1.AddRow(new string[] { "Property", "" });
                    table1.AddRow(new string[] { "IsPrivate", "" });
                    table1.AddRow(new string[] { "Status", "Reserved" });
                    _iwebstep.GetService().ThenUserVerifiesElementWithParameters("OLW_PLAYER_OFFER.lnkassignedprivateoffer", "true", table1);
                }
                else
                {
                    _iwebstep.GetService().ThenUserVerifiesElementWithParameters("OLW_PLAYER_OFFER.lnkassignedprivateoffer", "false", table1);
                }
                
            }
            else if (action.ToLower().Equals("redeem"))
            {
                _iwebstep.GetService().GivenUserEntersText(offer, "OLW_PLAYER_OFFER.txt_OfferName_Search");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_Authorization_Comment", offer);
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _iwebstep.GetService().ThenUserWaits("2");
                table1.AddRow(new string[] { "Status", "Active" });
                _iwebstep.GetService().GivenUserClicksOnWithParameters("OLW_PLAYER_OFFER.lnkassignedprivateoffer", table1);
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Redeem_Offer");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_Redeem_Offer");
                _iwebstep.GetService().GivenUserSwitchesToFrame("OLW_PLAYER_OFFER.frm_Redeem_Offer_Popup");                
                _iwebstep.GetService().GivenUserGetsAttributeElementToSaveWithKeyF("value", "OLW_PLAYER_OFFER.txtOfferValue", "offeramount");                
                try
                {
                    Double amt = Convert.ToDouble(_itestbasemanager.GetTestBase().GetTestDataUsingKey("offeramount").Replace("$", ""));
                    Double redeemamt = Convert.ToDouble(amount);
                    _iwebstep.GetService().WhenUserClears("OLW_PLAYER_OFFER.txt_Amount_To_Redeem");
                    _iwebstep.GetService().GivenUserEntersText(amount, "OLW_PLAYER_OFFER.txt_Amount_To_Redeem");
                    _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_Amount_To_Redeem", amount);
                    _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.btn_Popup_Redeem_Offer");
                    _ilog.Information("Clicked on OLW_PLAYER_OFFER.btn_Popup_Redeem_Offer");
                    _iwebstep.GetService().ThenUserWaits("5");
                    if (amt == redeemamt)
                    {
                        _iwebstep.GetService().ThenUserElement("selects", "OLW_PLAYER_OFFER.chk_Redeemed");
                        table1 = new Table(new string[] { "Key", "Value" });
                        table1.AddRow(new string[] { "OfferName", offer });
                        table1.AddRow(new string[] { "OfferType", "" });
                        table1.AddRow(new string[] { "StartDate", "" });
                        table1.AddRow(new string[] { "EndDate", "" });
                        table1.AddRow(new string[] { "Amount", "" });
                        table1.AddRow(new string[] { "Property", "" });
                        table1.AddRow(new string[] { "IsPrivate", "" });
                        table1.AddRow(new string[] { "Status", "Redeemed" });
                    }                    
                    
                }
                catch (Exception ex) {
                    _ilog.Error("Error while calculating remaining amount"+ex.Message);
                }
                _iwebstep.GetService().WhenUserClears("OLW_PLAYER_OFFER.txt_OfferName_Search");
                _iwebstep.GetService().GivenUserEntersText(offer, "OLW_PLAYER_OFFER.txt_OfferName_Search");
                _ilog.Information("Entered text {0} on OLW_PLAYER_OFFER.txt_OfferName_Search", offer);
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _ilog.Information("Clicked on OLW_PLAYER_OFFER.AssignedOffer_Search_Button");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().ThenUserVerifiesElementWithParameters("OLW_PLAYER_OFFER.lnkassignedprivateoffer", "true", table1);
                
            }
        
        }



        private void searchCampaign(String CampaignName, String Status, Table data)
        {
            String status = "CAMPAIGN_MANAGEMENT.";
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONFIGURATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.OFFER_MANAGEMENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.MANAGE_CAMPAIGN_LINK");
            switch (Status)
            {
                case "Active":
                    status += "ACTIVE_STATUS_CHECKBOX";
                    break;
                case "Approved":
                    status += "APPROVED_STATUS_CHECKBOX";
                    break;
                case "Ready for Approval":
                    status += "READY_APPROVAL_STATUS_CHECKBOX";
                    break;
                case "Inactive":
                    status += "CHK_INACTIVE";
                    break;
                case "Expired":
                    status += "EXPIRED_STATUS_CHECKBOX";
                    break;
                case "New":
                    status += "NEW_STATUS_CHECKBOX";
                    break;
                case "Not Approved":
                    status += "CHK_NOT_APPROVED";
                    break;
                case "Pending":
                    status += "";
                    break;
                case "Suspended":
                    status += "";
                    break;
            }
            _iwebstep.GetService().GivenUserClicksOn("CAMPAIGN_MANAGEMENT.CAMPAIGN_NAME");
            _iwebstep.GetService().GivenUserEntersText(CampaignName, "CAMPAIGN_MANAGEMENT.CAMPAIGN_NAME");
            _iwebstep.GetService().GivenUserClicksOn("CAMPAIGN_MANAGEMENT.STATUS_BUTTONIMAGE");
            _iwebstep.GetService().ThenUserElement("checks", status);
            _iwebstep.GetService().GivenUserClicksOn("CAMPAIGN_MANAGEMENT.STATUS_BUTTONIMAGE");
            _iwebstep.GetService().GivenUserClicksOn("CAMPAIGN_MANAGEMENT.SEARCH_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GivenUserClicksOnWithParameters("CAMPAIGN_MANAGEMENT.CAMPAIGN_LIST_TABLE", data);
        }
        private void viewCampaign()
        {
            _iwebstep.GetService().GivenUserClicksOn("CAMPAIGN_MANAGEMENT.VIEW_CAMPAIGN_BUTTON");

        }


        [When(@"Loyalty User change Campaign ""(.*)"" status from ""(.*)"" to ""(.*)""")]
        private void changeCampaignStatus(String CampaignName, String oldStatus, String status)
        {
            searchCampaign(CampaignName, oldStatus, ConvertStringtoTable("name:" + CampaignName));
            viewCampaign();
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(status, "NEW_CAMPAIGN.STATUS_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("NEW_CAMPAIGN.SAVE_BTN");
            switch (status)
            {
                case "Active":
                case "Approved":
                case "Suspended":
                case "Not Approved":
                    _iwebstep.GetService().GivenUserExecutesQuery("Update UC_X_OverrideType set ShowPassword=1,RequirePassword=1,ShowReason=1,RequireReason=1,ShowComment=1,RequireComment=1 where OverrideType='Activate Campaign'", " <#Halo_db_connectionstring#>");
                    _iwebstep.GetService().GivenUserExecutesQuery("Update UC_X_OverrideType set ShowPassword=1,RequirePassword=1,ShowReason=1,RequireReason=1,ShowComment=1,RequireComment=1 where OverrideType='Approve Campaign'", " <#Halo_db_connectionstring#>");
                    _iwebstep.GetService().GivenUserExecutesQuery("Update UC_X_OverrideType set ShowPassword=1,RequirePassword=1,ShowReason=1,RequireReason=1,ShowComment=1,RequireComment=1 where OverrideType='Suspend Campaign'", " <#Halo_db_connectionstring#>");
                    _iwebstep.GetService().GivenUserExecutesQuery("Update UC_X_OverrideType set ShowPassword=1,RequirePassword=1,ShowReason=1,RequireReason=1,ShowComment=1,RequireComment=1 where OverrideType='Campaign Not Approved'", " <#Halo_db_connectionstring#>");
                    _iwebstep.GetService().GivenUserClicksOn("NEW_CAMPAIGN.SAVE_BUTTON");
                    _iwebstep.GetService().ThenUserWaits("2");
                    if (status.Equals("Active"))
                    {
                        _iwebstep.GetService().GivenUserHandlesAlert("accepts");
                    }
                    _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "CAMPAIGN_MANAGEMENT.AUTHORISATION_PWD_TEXTBOX");
                    _iwebstep.GetService().GivenUserEntersText("Test Comments", "CAMPAIGN_MANAGEMENT.AUTHORISATION_COMMENT_TEXTAREA");
                    _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("1", "CAMPAIGN_MANAGEMENT.AUTHORISATION_REASON_DROPDOWN", "index");
                    _iwebstep.GetService().GivenUserClicksOn("CAMPAIGN_MANAGEMENT.AUTHORISATION_SUBMIT_BUTTON");
                    _iwebstep.GetService().GivenUserClicksOn("NEW_CAMPAIGN.SUCCESS_MESSAGE_OK_BUTTON");
                    break;
                default:
                    _iwebstep.GetService().GivenUserClicksOn("NEW_CAMPAIGN.SAVE_BUTTON");
                    _iwebstep.GetService().ThenUserWaits("2");
                    _iwebstep.GetService().GivenUserClicksOn("NEW_CAMPAIGN.SUCCESS_MESSAGE_OK_BUTTON");
                    break;
            }
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("NEW_CAMPAIGN.CANCEL_BUTTON");
        }

    }
}
