﻿using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.WebAbstraction;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty.Configuration
{
    [Binding]
    class BucketAndViewManagement : LoyaltyBase
    {
        IWebStepDef _iwebstep;
        ITestStepBuilder _iteststepbuilder;
        ITestBaseManager _itestbasemanager;
        IUiActions _iuiactions;
        IObjectBuilder _iobjectbuilder;
        Dictionary<string, string> _datatable;


        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _itestbasemanager = Cucumber._serviceprovider.GetService<ITestBaseManager>();
            _iuiactions = Cucumber._serviceprovider.GetService<IUiActions>();
            _iobjectbuilder = Cucumber._serviceprovider.GetService<IObjectBuilder>();
        }


        [Given(@"EB user create Bucket ""(.*)"" with parameters")]
        public void GivenEBUsercreatebucketWithParameters(String BucketName, Table parameters)
        {
            _iwebstep.GetService().GivenUserEntersText("Configure Buckets", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONF_BUCKETS");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.lnk_eb_AddBucket");
            _iwebstep.GetService().ThenUserWaits("8");
            _iwebstep.GetService().GivenUserEntersText(BucketName, "MANAGE_EXTEND_BUCKET.txt_eb_Bucket_Name");
            _iwebstep.GetService().ThenUserWaits("2");
            _datatable = new Dictionary<string, string>();
            for (int i = 0; i < parameters.RowCount; i++)
            {
                _datatable.Add(parameters.Rows[i][0], parameters.Rows[i][1]);

            }
            foreach (var item in _datatable)
            {
                switch (item.Key)
                {
                    case "Money Value":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.rdb_eb_moneyValue");
                            }
                            break;

                        }
                    case "Currency":
                        {
                            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(item.Value, "MANAGE_EXTEND_BUCKET.tbl_eb_currency", "visibletext");
                            break;
                        }
                    case "Precession":
                        {
                            _iwebstep.GetService().GivenUserEntersText(item.Value, "MANAGE_EXTEND_BUCKET.txt_eb_precision");
                            break;
                        }
                    case "FIFO":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BalanceUsage_FIFO");
                            }
                            break;
                        }
                    case "Allow Negative":
                        {
                            if (item.Value == "checks")
                            {
                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Allow Comp Items":
                        {
                            if (item.Value == "checks")
                            {
                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                                _iwebstep.GetService().ThenUserWaits("2");
                            }
                            break;
                        }
                    case "Visible To Players":
                        {
                            if (item.Value == "checks")
                            {
                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Consolidated Bucket":
                        {
                            if (item.Value == "checks")
                            {
                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                                _iwebstep.GetService().ThenUserWaits("2");
                            }
                            break;
                        }
                    case "Exclusive Bucket":
                        {
                            if (item.Value == "checks")
                            {
                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Functional Authorization":
                        {
                            if (item.Value == "checks")
                            {

                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Discretionary Comp":
                        {
                            if (item.Value == "checks")
                            {
                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Redeemable at EGM":
                        {
                            if (item.Value == "checks")
                            {
                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "EarningTimePeriod":
                        {
                            if (item.Value == "Ongoing")
                            {
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.rdb_eb_earningOngoing");
                            }
                            break;
                        }
                    case "EarningTime":
                        {

                            String[] time = item.Value.Split("-");
                            try
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.rdb_eb_earningOngoing");
                                _iwebstep.GetService().GivenUserEntersText(time[0], "MANAGE_EXTEND_BUCKET.txt_eb_earningStartDate");


                            }
                            catch
                            {
                                _iwebstep.GetService().GivenUserEntersText(time[0], "MANAGE_EXTEND_BUCKET.txt_eb_earningStartDate");
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.txt_eb_earningEndDate");
                                _iwebstep.GetService().GivenUserEntersText(time[1], "MANAGE_EXTEND_BUCKET.txt_eb_earningEndDate");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.txt_eb_earnsEndTime");


                            }
                            break;
                        }
                    case "RedemptionTimePeriod":
                        {
                            _iwebstep.GetService().ThenUserWaits("2");
                            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.rdb_eb_redemptionOngoing");
                            break;
                        }
                    case "RedemptionTime":
                        {

                            String[] time = item.Value.Split("-");
                            try
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.rdb_eb_redemptionOngoing");
                                _iwebstep.GetService().GivenUserEntersText(time[0], "MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");

                            }
                            catch
                            {
                                 _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");
                                _iwebstep.GetService().GivenUserEntersText(time[0], "MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.txt_eb_redemEndDate");
                                _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.txt_eb_redemEndDate");
                                _iwebstep.GetService().GivenUserEntersText(time[1], "MANAGE_EXTEND_BUCKET.txt_eb_redemEndDate");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.txt_eb_redemEndTime");
                            }
                            break;
                        }
                    default:
                        //Log error.
                        break;

                }

            }

	 //Handling Conversion rate for numeric bucket.
	 if(!_datatable.ContainsKey("Money Value"))
            {
                Table tabley = new Table(new string[] { "Key", "Value" });
                tabley.AddRow(new string[] { "option", "US Dollar" });
                _iwebstep.GetService().GivenUserEntersText("1", "MANAGE_EXTEND_BUCKET.Conversion_Rate");
                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.Conversaion_CurrencyDrpdwn");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserEntersText("US Dollar", "MANAGE_EXTEND_BUCKET.Conversion_Currency_Drp_Search");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserClicksOnWithParameters("MANAGE_EXTEND_BUCKET.Dropdown_Option", tabley);
                _iwebstep.GetService().ThenUserWaits("1");
            }
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("MANAGE_EXTEND_BUCKET.btn_eb_Save");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.btn_eb_Save");
            _iwebstep.GetService().ThenUserWaits("2");
	    //Setting Buckets Limits.
            _iwebstep.GetService().GivenUserEntersText("10000", "MANAGE_EXTEND_BUCKET.txt_limit_maxbalance");
            _iwebstep.GetService().GivenUserEntersText("10000", "MANAGE_EXTEND_BUCKET.txt_limit_MaxEarnPerDay");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("MANAGE_EXTEND_BUCKET.btn_limit_SaveContinue");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.btn_limit_SaveContinue");
            _iwebstep.GetService().ThenUserWaits("2");
            //Verifying Bucket Name in  DB.
            String sql = "Select count(BucketName) from [dbo].[Buckets] where BucketName = '" + BucketName + "'";
            String dbconnectionstring = "<#Halo_db_connectionstring#>";
            String key = "DBBucketCount";
            _iwebstep.GetService().GivenUserRunsQuery(sql, dbconnectionstring, key);
            _iwebstep.GetService().GivenUserPerformOperations("numberEquals", "1", "<$DBBucketCount$>");
            //Verifying default bucket view name in DB.
            String sql2 = "Select count(BucketViewName) from dbo.BucketViews where BucketViewName = '" + BucketName + "'";
            _iwebstep.GetService().GivenUserRunsQuery(sql2, dbconnectionstring, "DBBucketviewCount");
            _iwebstep.GetService().GivenUserPerformOperations("numberEquals", "1", "<$DBBucketviewCount$>");
            _iwebstep.GetService().ThenUserWaits("2");
            //Providing the Permission from Edit Bucket Association screen.
            _iwebstep.GetService().GivenUserEntersText("Group Permissions", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.GROUP_PERMISSIONS_LINK");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy("UC_Admin", "USER_GROUP_PERMISSIONS.USER_GROUP_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("USER_GROUP_PERMISSIONS.btnEditbucketassociations");
            _iwebstep.GetService().GivenUserEntersText(BucketName, "MANAGE_EXTEND_BUCKET.txt_GroupPermission_Search");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.btn_GroupPermission_Search");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.chk_GroupPermission_Checkbox");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.btn_GroupPermission_Save");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().VerifyTextOnTheScreen("Permission saved successfully.");
            //Providing Adjustmetn Limit from Player Transaction Adjustment Limit By Bucket type.
            if (!_datatable.ContainsKey("Discretionary Comp"))
            {
                _iwebstep.GetService().GivenUserEntersText("Player Transaction Limits", "MAIN_NAV_BOX.EB_MenuSearch");
                _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYERTRANSACTIONSLIMIT_LINK");
                _iwebstep.GetService().GivenUserSelectsOptionOfElementBy("UC_Admin", "USER_GROUP_PERMISSIONS.USER_GROUP_DROPDOWN", "visibletext");
                _iwebstep.GetService().GivenUserClicksOn("PLAYER_TRANS_LIMITS.tabAdjustLimitByBucket");
                _iwebstep.GetService().GivenUserClicksOn("PLAYER_TRANS_LIMITS.SelectBucketDrpdown");
                _iwebstep.GetService().GivenUserEntersText(BucketName, "PLAYER_TRANS_LIMITS.txtBucket");
                _iwebstep.GetService().GivenUserClicksOnWithParameters("PLAYER_TRANS_LIMITS.SELECT_BUCKET_ADJUSTMENT", ConvertStringtoTable("AdjustmentBucket:" + BucketName));
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().WhenUserClears("PLAYER_TRANS_LIMITS.txtMaxAdjustment");
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserEntersText("1000", "PLAYER_TRANS_LIMITS.txtMaxAdjustment");
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserClicksOn("PLAYER_TRANS_LIMITS.btnAddUpdate");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserClicksOn("PLAYER_TRANS_LIMITS.btnSaveAdjLimit");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().VerifyTextOnTheScreen("Adjustment limits saved!");
            }
        }

        [Given(@"EB User update bucket ""(.*)"" with parameters")]
        public void GivenEBUserupdatebucketwithParameters(String BucketName, Table parameters)
        {
            _iwebstep.GetService().GivenUserEntersText("Configure Buckets", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONF_BUCKETS");
            _iwebstep.GetService().GivenUserEntersText(BucketName, "MANAGE_EXTEND_BUCKET.SearchBucketName");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(BucketName, "MANAGE_EXTEND_BUCKET.SelectBucketBySelect", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _datatable = new Dictionary<string, string>();
            for (int i = 0; i < parameters.RowCount; i++)
            {
                _datatable.Add(parameters.Rows[i][0], parameters.Rows[i][1]);

            }
            _iwebstep.GetService().ThenUserWaits("4");
            foreach (var item in _datatable)
            {
                switch (item.Key)
                {

                    case "Money Value":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.rdb_eb_moneyValue");
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElement("unchecks", "MANAGE_EXTEND_BUCKET.rdb_eb_moneyValue");

                            }
                            break;
                        }
                    case "Numeric":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.rdb_Numeric");
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElement("unchecks", "MANAGE_EXTEND_BUCKET.rdb_Numeric");

                            }
                            break;
                        }
                    case "Currency":
                        {
                            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(item.Value, "MANAGE_EXTEND_BUCKET.tbl_eb_currency", "visibletext");
                            break;
                        }
                    case "Precession":
                        {
                            _iwebstep.GetService().GivenUserEntersText(item.Value, "MANAGE_EXTEND_BUCKET.txt_eb_precision");
                            break;
                        }
                    case "CPF":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BalanceUsage_CPF");
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElement("unchecks", "MANAGE_EXTEND_BUCKET.BalanceUsage_CPF");
                            }
                            break;
                        }
                    case "FIFO":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BalanceUsage_FIFO");
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElement("unchecks", "MANAGE_EXTEND_BUCKET.BalanceUsage_FIFO");
                            }
                            break;
                        }
                    case "Allow Negative":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("checks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("unchecks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Allow Comp Items":
                        {
                            _iwebstep.GetService().ThenUserWaits("2");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("checks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("unchecks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Visible To Players":
                        {
                            _iwebstep.GetService().ThenUserWaits("2");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("checks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("unchecks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Consolidated Bucket":
                        {
                            _iwebstep.GetService().ThenUserWaits("2");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("checks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("unchecks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Exclusive Bucket":
                        {
                            _iwebstep.GetService().ThenUserWaits("2");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("checks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("unchecks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Functional Authorization":
                        {
                            _iwebstep.GetService().ThenUserWaits("2");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("checks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("unchecks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Redeemable at EGM":
                        {
                            _iwebstep.GetService().ThenUserWaits("2");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("checks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElementWithElement("unchecks", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "EarningTime":
                        {
                            String[] time = item.Value.Split("-");
                            try
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.rdb_eb_earningOngoing");
                                _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.txt_eb_earningStartDate");
                                _iwebstep.GetService().GivenUserEntersText(time[0], "MANAGE_EXTEND_BUCKET.txt_eb_earningStartDate");

                            }
                            catch
                            {
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.txt_eb_earningStartDate");
                                _iwebstep.GetService().GivenUserEntersText(time[0], "MANAGE_EXTEND_BUCKET.txt_eb_earningStartDate");
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.txt_eb_earningEndDate");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.txt_eb_earningEndDate");
                                _iwebstep.GetService().GivenUserEntersText(time[1], "MANAGE_EXTEND_BUCKET.txt_eb_earningEndDate");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.txt_eb_earnsEndTime");

                            }
                            break;
                        }
                    case "RedemptionTime":
                        {
                            String[] time = item.Value.Split("-");
                            try
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.rdb_eb_redemptionOngoing");
                                _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");
                                _iwebstep.GetService().GivenUserEntersText(time[0], "MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");

                            }
                            catch
                            {
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");
                                _iwebstep.GetService().GivenUserEntersText(time[0], "MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.txt_eb_redemEndDate");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.txt_eb_redemEndDate");
                                _iwebstep.GetService().GivenUserEntersText(time[1], "MANAGE_EXTEND_BUCKET.txt_eb_redemEndDate");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.txt_eb_redemEndTime");
                            }
                            break;
                        }
                    default:
                        //log error.
                        break;

                }
            }
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("MANAGE_EXTEND_BUCKET.btn_eb_Save");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.btn_eb_Save");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.tab_bucketDefTab");
            _iwebstep.GetService().ThenUserWaits("2");
            foreach (var item in _datatable)
            {
                switch (item.Key)
                {
                    case "Money Value":
                        {
                            _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.rdb_eb_moneyValue");
                            break;
                        }
                    case "Numeric":
                        {
                            _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.rdb_Numeric");
                            break;
                        }
                    case "Currency":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "currency", item.Value });
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("selected", "true", "MANAGE_EXTEND_BUCKET.SelectCurrencyType", tablex);
                            break;
                        }
                    case "Precession":
                        {
                            _iwebstep.GetService().GivenUserVerifyAttribute("value", item.Value, "MANAGE_EXTEND_BUCKET.txt_eb_precision");
                            break;
                        }
                    case "CPF":
                        {
                            _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.BalanceUsage_CPF");
                            break;
                        }
                    case "FIFO":
                        {
                            _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.BalanceUsage_FIFO");
                            break;
                        }
                    case "Allow Negative":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("checked", "true", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("selected", "false", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Allow Comp Items":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("checked", "true", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("selected", "false", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Visible To Players":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("checked", "true", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("selected", "false", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Consolidated Bucket":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("checked", "true", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("selected", "false", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Exclusive Bucket":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("checked", "true", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("selected", "false", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Functional Authorization":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("checked", "true", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("selected", "false", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "Redeemable at EGM":
                        {
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "Bucketsetting", item.Key });
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("checked", "true", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttributeParameters("selected", "false", "MANAGE_EXTEND_BUCKET.chk_eb_bucketSetting", tablex);
                            }
                            break;
                        }
                    case "EarningTime":
                        {
                            String[] time = item.Value.Split("-");
                            try
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.rdb_eb_earningOngoing");
                                _iwebstep.GetService().GivenUserVerifyAttribute("value", time[0], "MANAGE_EXTEND_BUCKET.txt_eb_earningStartDate");

                            }
                            catch
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("value", time[0], "MANAGE_EXTEND_BUCKET.txt_eb_earningStartDate");
                                _iwebstep.GetService().GivenUserVerifyAttribute("value", time[1], "MANAGE_EXTEND_BUCKET.txt_eb_earningEndDate");
                            }

                            break;
                        }
                    case "RedemptionTime":
                        {
                            String[] time = item.Value.Split("-");
                            try
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.rdb_eb_redemptionOngoing");
                                _iwebstep.GetService().GivenUserVerifyAttribute("value", time[0], "MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");

                            }
                            catch
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("value", time[0], "MANAGE_EXTEND_BUCKET.txt_eb_redemStartDate");
                                _iwebstep.GetService().GivenUserVerifyAttribute("value", time[1], "MANAGE_EXTEND_BUCKET.txt_eb_redemEndDate");
                            }
                            break;
                        }
                    default:
                        //log error.
                        break;

                }
            }


        }

               [Given(@"EB User create bucket view ""(.*)"" with parameters")]
        public void GivenEBUsercreatebucketviewwithParameters(String BucketviewName, Table parameters)
        {
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("Manage Bucket View", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.MANAGE_BUCKET_VIEW");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.img_bucketView_addBucketView");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText(BucketviewName, "MANAGE_EXTEND_BUCKET.BucketView_ViewName");
            _iwebstep.GetService().GivenUserEntersText(BucketviewName, "MANAGE_EXTEND_BUCKET.BucketView_DisplayName");
            _iwebstep.GetService().GivenUserEntersText(BucketviewName, "MANAGE_EXTEND_BUCKET.BucketView_XMLreturnName");
            _datatable = new Dictionary<string, string>();
            for (int i = 0; i < parameters.RowCount; i++)
            {
                _datatable.Add(parameters.Rows[i][0], parameters.Rows[i][1]);

            }
            foreach (var item in _datatable)
            {
                switch (item.Key)
                {
                    case "Combined Bucket View":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BucketView_CombinedBucketView");
                                _iwebstep.GetService().ThenUserWaits("2");
                            }
                            break;
                        }
                    case "Allow Exception Views":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BucketView_AllowExceptionView");
                                _iwebstep.GetService().ThenUserWaits("2");
                            }
                            break;
                        }
                    case "Allow Awards":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BucketView_AllowAwards");
                            }
                            break;
                        }
                    case "Allow Corporate Rewards":
                        {
                            if(item.Value =="checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BucketView_AllowCrptAwards");
                            }
                            break;
                        }
                    case "BucketsAdd":
                        {
                            String[] bucket = item.Value.Split(",");
                            foreach(var name in bucket)
                            {
                                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(name, "MANAGE_EXTEND_BUCKET.BucketView_SelectBucket", "visibletext");
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.BucketView_AddRight");
                                _iwebstep.GetService().ThenUserWaits("2");

                            }

                            break;
                        }
                    default:
                        //Log error
                        break;
                }
                
            }
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.BucketView_Next");
            _iwebstep.GetService().ThenUserWaits("4");
            //Copper tier
              foreach (var item in _datatable)
            {
                switch(item.Key)
                {
                    case "Copper":
                        {
                           
                            {
                                String[] limit = item.Value.Split(",");
                                Table tablex = new Table(new string[] { "Key", "Value" });
                                tablex.AddRow(new string[] { "avlTier", item.Key });
                                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                                _iwebstep.GetService().ThenUserWaits("2");
                            }
                            break;
                        }
                    case "Silver":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Gold":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Platinum":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Diamond":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Employee":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    default:
                        //Log error.
                        break;
                }
            }
            if(!(_datatable.ContainsKey("Copper")))
            {
                Table tablex = new Table(new string[] { "Key", "Value" });
                tablex.AddRow(new string[] { "avlTier", "Copper" });
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("1", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("2", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("4", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                _iwebstep.GetService().ThenUserWaits("2");
            }
            if (!(_datatable.ContainsKey("Silver")))
            {
                Table tablex = new Table(new string[] { "Key", "Value" });
                tablex.AddRow(new string[] { "avlTier", "Silver" });
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("1", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("2", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("4", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                _iwebstep.GetService().ThenUserWaits("2");
            }
            if (!(_datatable.ContainsKey("Gold")))
            {
                Table tablex = new Table(new string[] { "Key", "Value" });
                tablex.AddRow(new string[] { "avlTier", "Gold" });
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("1", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("2", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("4", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                _iwebstep.GetService().ThenUserWaits("2");
            }
            if (!(_datatable.ContainsKey("Diamond")))
            {
                Table tablex = new Table(new string[] { "Key", "Value" });
                tablex.AddRow(new string[] { "avlTier", "Diamond" });
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("1", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("2", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("4", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                _iwebstep.GetService().ThenUserWaits("2");
            }
            if (!(_datatable.ContainsKey("Platinum")))
            {
                Table tablex = new Table(new string[] { "Key", "Value" });
                tablex.AddRow(new string[] { "avlTier", "Platinum" });
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("1", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("2", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("4", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                _iwebstep.GetService().ThenUserWaits("2");
            }
            if (!(_datatable.ContainsKey("Employee")))
            {
                Table tablex = new Table(new string[] { "Key", "Value" });
                tablex.AddRow(new string[] { "avlTier", "Employee" });
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("1", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("2", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters("4", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                _iwebstep.GetService().ThenUserWaits("2");
            }
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.BucketView_Save");
            _iwebstep.GetService().ThenUserWaits("4");
            //Verifying the Bucket view name in DB
            String sql = "Select COUNT(BucketViewID) from dbo.BucketViews where BucketViewName = '" + BucketviewName + "'";
            String dbconnectionstring = "<#Halo_db_connectionstring#>";
            String key = "DBBucketviewCount";
            _iwebstep.GetService().GivenUserRunsQuery(sql, dbconnectionstring, key);
            _iwebstep.GetService().GivenUserPerformOperations("numberEquals", "1", "<$DBBucketviewCount$>");
        }

        [Given(@"EB User update bucket view ""(.*)"" with parameters")]
        public void GivenEBUserUpdateBucketViewWithParameters(String BucketviewName, Table parameters)
        {
            //Verifying transaction on bucketview.
            String dbconnectionstring = "<#Halo_db_connectionstring#>";
            String key = "TransactionCount";
            String sql = "Select count(TransactionID)from EB.Transactions where BucketViewID In (Select BucketViewID from dbo.BucketViews where BucketViewName  = '" + BucketviewName + "')";
            _iwebstep.GetService().GivenUserRunsQuery(sql, dbconnectionstring, key);
            String trxcount = _itestbasemanager.GetTestBase().GetTestDataUsingKey(key);
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("Manage Bucket View", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.MANAGE_BUCKET_VIEW");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText(BucketviewName, "MANAGE_EXTEND_BUCKET.BucketView_Search");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(BucketviewName, "MANAGE_EXTEND_BUCKET.BucketView_createdview", "visibletext");
            _iwebstep.GetService().ThenUserWaits("4");
            _datatable = new Dictionary<string, string>();
            for (int i = 0; i < parameters.RowCount; i++)
            {
                _datatable.Add(parameters.Rows[i][0], parameters.Rows[i][1]);

            }
            foreach (var item in _datatable)
            {
                switch (item.Key)
                {
                    case "Display Name":
                        {
                            _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.BucketView_DisplayName");
                            _iwebstep.GetService().GivenUserEntersText(item.Value, "MANAGE_EXTEND_BUCKET.BucketView_DisplayName");
                            break;
                        }
                    case "XML Return Name":
                        {
                            if (Convert.ToInt32(trxcount) == 0)
                            {
                                _iwebstep.GetService().WhenUserClears("MANAGE_EXTEND_BUCKET.BucketView_XMLreturnName");
                                _iwebstep.GetService().GivenUserEntersText(item.Value, "MANAGE_EXTEND_BUCKET.BucketView_XMLreturnName");
                            }
                            else
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("disabled", "true", "MANAGE_EXTEND_BUCKET.BucketView_XMLreturnName");
                            }
                            break;
                        }
                    case "Allow Exception Views":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BucketView_AllowExceptionView");
                                _iwebstep.GetService().ThenUserWaits("2");
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElement("unchecks", "MANAGE_EXTEND_BUCKET.BucketView_AllowExceptionView");
                                _iwebstep.GetService().ThenUserWaits("2");
                            }

                            break;
                        }
                    case "Allow Awards":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BucketView_AllowAwards");
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElement("unchecks", "MANAGE_EXTEND_BUCKET.BucketView_AllowAwards");
                            }

                            break;
                        }
                    case "Allow Corporate Rewards":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().ThenUserElement("checks", "MANAGE_EXTEND_BUCKET.BucketView_AllowCrptAwards");
                            }
                            else if (item.Value == "unchecks")
                            {
                                _iwebstep.GetService().ThenUserElement("unchecks", "MANAGE_EXTEND_BUCKET.BucketView_AllowCrptAwards");
                            }

                            break;
                        }
                    case "BucketAdd":
                        {
                            String[] bucket = item.Value.Split(",");
                            foreach (var name in bucket)
                            {
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(name, "MANAGE_EXTEND_BUCKET.BucketView_SelectBucket", "visibletext");
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.BucketView_AddRight");
                                _iwebstep.GetService().ThenUserWaits("2");

                            }
                            break;
                        }
                    case "BucketRemove":
                        {
                            String[] bucket = item.Value.Split();
                            if (Convert.ToInt32(trxcount) == 0)
                            {
                                foreach (var name in bucket)
                                {
                                    try
                                    {
                                        _iwebstep.GetService().GivenUserVerifyAttribute("disabled", "true", "MANAGE_EXTEND_BUCKET.BucketView_ExcludeLeft");
                                        _iwebstep.GetService().ThenUserWaits("2");
                                    }
                                    catch
                                    {
                                        _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(name, "MANAGE_EXTEND_BUCKET.BucketView_BucketRightPane", "visibletext");
                                        _iwebstep.GetService().ThenUserWaits("1");
                                        _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.BucketView_ExcludeLeft");
                                        _iwebstep.GetService().ThenUserWaits("2");
                                    }
                                }
                            }
                            break;
                        }
                    default:
                        //Log Error.
                        break;

                }

            }
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.BucketView_Next");
            _iwebstep.GetService().ThenUserWaits("4");
            foreach (var item in _datatable)
            {
                switch (item.Key)
                {
                    case "Copper":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Silver":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Gold":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Platinum":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Diamond":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    case "Employee":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[0], "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[1], "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iteststepbuilder.ResetStepData();
                            _iuiactions.ClearTextBox(_iteststepbuilder.SetUiObject(_iobjectbuilder.BuildFromName("MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal")).SetStepDataTable(tablex).Build());
                            _iwebstep.GetService().ThenUserEntersWithoutDelayOnWithParameters(limit[2], "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            _iwebstep.GetService().ThenUserWaits("2");
                            break;
                        }
                    default:
                        //Log error.
                        break;
                }
            }
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.BucketView_Save");
            _iwebstep.GetService().ThenUserWaits("4");
            //User verfiy the changes.
            foreach (var item in _datatable)
            {
                switch (item.Key)
                {
                    case "Display Name":
                        {
                            _iwebstep.GetService().GivenUserVerifyAttribute("value", item.Value, "MANAGE_EXTEND_BUCKET.BucketView_DisplayName");
                            break;
                        }
                    case "XML Return Name":
                        {
                            _iwebstep.GetService().GivenUserVerifyAttribute("value", item.Value, "MANAGE_EXTEND_BUCKET.BucketView_XMLreturnName");
                            break;
                        }
                    case "Allow Exception Views":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.BucketView_AllowExceptionView");
                            }
                            else
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("selected", "false", "MANAGE_EXTEND_BUCKET.BucketView_AllowExceptionView");
                            }
                            break;
                        }
                    case "Allow Awards":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.BucketView_AllowAwards");
                            }
                            else
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("selected", "false", "MANAGE_EXTEND_BUCKET.BucketView_AllowAwards");
                            }
                            break;
                        }
                    case "Allow Corporate Rewards":
                        {
                            if (item.Value == "checks")
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("checked", "true", "MANAGE_EXTEND_BUCKET.BucketView_AllowCrptAwards");
                            }
                            else
                            {
                                _iwebstep.GetService().GivenUserVerifyAttribute("selected", "false", "MANAGE_EXTEND_BUCKET.BucketView_AllowCrptAwards");
                            }
                            break;
                        }
                    case "BucketRemove":
                        {
                            _iwebstep.GetService().ThenUserVerifyAllListOptions("MANAGE_EXTEND_BUCKET.BucketView_SelectBucket", item.Value);
                            break;
                        }
                    case "BucketAdd":
                        {
                            _iwebstep.GetService().ThenUserVerifyAllListOptions("MANAGE_EXTEND_BUCKET.BucketView_BucketRightPane", item.Value);
                            break;
                        }
                    default:
                        //Log error.
                        break;
                }
            }
            _iwebstep.GetService().GivenUserClicksOn("MANAGE_EXTEND_BUCKET.BucketView_Next");
            _iwebstep.GetService().ThenUserWaits("4");
            foreach(var item in _datatable)
            {
                switch(item.Key)
                {
                    case "Copper":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[0] +".0", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[1] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[2] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            break;
                        }
                    case "Silver":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[0] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[1] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[2] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            break;
                        }
                    case "Gold":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[0] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[1] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[2] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            break;
                        }
                    case "Platinum":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[0] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[1] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[2] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            break;
                        }
                    case "Diamond":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[0] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[1] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[2] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            break;
                        }
                    case "Employee":
                        {
                            String[] limit = item.Value.Split(",");
                            Table tablex = new Table(new string[] { "Key", "Value" });
                            tablex.AddRow(new string[] { "avlTier", item.Key });
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[0] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MinRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[1] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxRedTranVal", tablex);
                            _iwebstep.GetService().GivenUserVerifyAttributeParameters("value", limit[2] + ".0", "MANAGE_EXTEND_BUCKET.BucketView_MaxDalRedVal", tablex);
                            break;
                        }
                    default:
                        //Log error.
                        break;
                }
            }
		

        }



    }
}
