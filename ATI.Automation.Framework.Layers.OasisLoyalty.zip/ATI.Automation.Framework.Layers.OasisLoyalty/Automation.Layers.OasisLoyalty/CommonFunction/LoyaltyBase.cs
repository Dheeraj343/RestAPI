﻿using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty
{
    public class LoyaltyBase
    {
        public List<Dictionary<string, string>> ConvertTabletoString(Table dt)
        {

            var lstDict = new List<Dictionary<string, string>>();
            if (dt != null)
            {
                var headers = dt.Header;
                var dict = new Dictionary<string, string>();
                foreach (var row in dt.Rows)
                {
                    foreach (var header in headers)
                    {
                        dict.Add(header, row[header]);
                    }

                    lstDict.Add(dict);
                    Console.WriteLine(lstDict);
                    foreach (var val in lstDict)
                    {

                    }
                    Console.WriteLine(lstDict[0].Values);

                }
            }

            return lstDict;
        }

        public Table ConvertStringtoTable(params String[] b)
        {
            Table dt = new Table(new string[] { "Key", "Value" });
            foreach (String a in b)
            {
                String[] temp = a.Split(":");
                dt.AddRow(new string[] { temp[0], temp[1] });
            }
            return dt;
        }

    }
}
