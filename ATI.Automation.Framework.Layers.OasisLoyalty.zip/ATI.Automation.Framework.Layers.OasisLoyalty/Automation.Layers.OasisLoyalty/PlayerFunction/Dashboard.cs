﻿using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.WebAbstraction;
using Automation.Framework.Exceptions;
using AventStack.ExtentReports.Gherkin.Model;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Transactions;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty
{
    [Binding]
    public class Dashboard : LoyaltyBase
    {
        ITestStepBuilder _iteststepbuilder;
        ITestStep _iteststep;
        IWebStepDef _iwebstep;
        ITestBaseManager _itestbasemanager;

        Dictionary<string, string> bucketEarningtab = new Dictionary<string, string>();
        Dictionary<string, string> tripDetails = new Dictionary<string, string>();
        Dictionary<string, string> compDetails = new Dictionary<string, string>();
        Dictionary<string, string> _datatable = new Dictionary<string, string>();
        Dictionary<string, string> Transactiontab = new Dictionary<string, string>();
        Dictionary<string, string> balance = new Dictionary<string, string>();
        Dictionary<string, string> Earningtab = new Dictionary<string, string>();


        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();
            _itestbasemanager = Cucumber._serviceprovider.GetService<ITestBaseManager>();

        }


        [Then(@"Loyalty User verify ""(.*)"" tab with parameters")]
        public void ThenLoyaltyUserVerifyTabWithParameters(string tabname, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            bucketEarningtab = _iteststep.GetMultiRowDataTable()[0];
            String positivecomps = "";
            switch (tabname)
            {
                case "PointsEarnings":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.POINTS_EARNINGS_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("POINTS_EARNINGS.POINTS_EARNINGS_FRAME");
                    _iwebstep.GetService().GivenUserClicksOn("POINTS_EARNINGS.POINTS_FIRST_EXPAND_IMAGE");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("POINTS_EARNINGS.POINTS_EXPANDED_ROW", ConvertStringtoTable("date:" + bucketEarningtab["date"], "property:" + bucketEarningtab["property"], "type:" + bucketEarningtab["type"], "points:" + bucketEarningtab["points"]));
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    break;

                case "CompsEarnings":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.COMPS_EARNINGS_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("COMPS_EARNINGS.COMPS_EARNINGS_FRAME");
                    _iwebstep.GetService().GivenUserClicksOn("COMPS_EARNINGS.COMPS_FIRST_EXPAND_IMAGE");
                    _iwebstep.GetService().GivenUserSavesArithmeticOperationsValue("mod", bucketEarningtab["points"], "", positivecomps);
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("COMPS_EARNINGS.COMPS_EXPANDED_ROW", ConvertStringtoTable("date:" + bucketEarningtab["date"], "property:" + bucketEarningtab["property"], "type:" + bucketEarningtab["type"], "credits:" + positivecomps));
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    break;

                case "TierpointsEarnings":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.TIER_CREDIT_EARNINGS_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("TIER_CREDIT_EARNINGS.TIER_CREDIT_EARNINGS_FRAME");
                    _iwebstep.GetService().GivenUserClicksOn("TIER_CREDIT_EARNINGS.TIER_FIRST_EXPAND_IMAGE");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("TIER_CREDIT_EARNINGS.TIER_EXPANDED_ROW", ConvertStringtoTable("date:" + bucketEarningtab["date"], "property:" + bucketEarningtab["property"], "type:" + bucketEarningtab["type"], "credits:" + bucketEarningtab["points"]));
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    break;

                case "GiftpointEarnings":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.INVENTORY_CASH_EARNINGS_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("INVENTORY_CASH_EARNING.INV_CASH_FRAME");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("INVENTORY_CASH_EARNING.imgGiftpointsearning_expandusingdate", ConvertStringtoTable("gamingdate:" + bucketEarningtab["date"]));
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("INVENTORY_CASH_EARNING.INV_EXPANDED_ROW", ConvertStringtoTable("date:" + bucketEarningtab["date"], "property:" + bucketEarningtab["property"], "type:" + bucketEarningtab["type"], "invcash:" + bucketEarningtab["points"]));
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("INVENTORY_CASH_EARNING.imgGiftpointsearning_expandusingdate", ConvertStringtoTable("gamingdate:" + bucketEarningtab["date"]));
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    break;

                case "RunningBalances":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.RUNNING_BALANCES_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("RUNNING_BALANCES.RUNNING_BALANCES_FRAME");
                    _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(bucketEarningtab["bucket"], "RUNNING_BALANCES.RUNNING_BALANCES_ACCOUNT_TYPE_DROPDOWN", "visibletext");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("RUNNING_BALANCES.imgRunningbal_gamingdate_imgexpand", ConvertStringtoTable("gamingdate:" + bucketEarningtab["date"]));
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("RUNNING_BALANCES.RUNNING_BALANCES_EXPANDED_ROW", ConvertStringtoTable("date:" + bucketEarningtab["date"], "type:" + bucketEarningtab["type"], "originator:" + bucketEarningtab["originator"], "points:" + bucketEarningtab["points"], "balance:" + bucketEarningtab["balance"]));
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("RUNNING_BALANCES.imgRunningbal_gamingdate_imgexpand", ConvertStringtoTable("gamingdate:" + bucketEarningtab["date"]));
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    break;

                case "PointsTransactions":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.POINTS_TRANSACTIONS_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("POINTS_TRANSACTIONS.POINTS_TANSACTIONS_FRAME");
                    _iwebstep.GetService().ThenUserVerifiesElement("POINTS_TRANSACTIONS.POINTS_TRANSACTIONS_ROWCOUNT", "true");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("POINTS_TRANSACTIONS.POINTS_TANSACTIONS_ROW", ConvertStringtoTable("date:" + bucketEarningtab["date"], "property:" + bucketEarningtab["property"], "outlet:" + bucketEarningtab["outlet"], "status:" + bucketEarningtab["status"], "points:" + bucketEarningtab["points"], "type:" + bucketEarningtab["type"], "dollarvalue:" + bucketEarningtab["dollarvalue"], "Voidable:" + bucketEarningtab["void"]));
                    _iwebstep.GetService().GivenUserClicksOn("COMP_TRANSACTIONS.btnViewcompdetail");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["status"], "POINTS_TRANSACTIONS.lblPointdetail_transactiontype");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["points"], "POINTS_TRANSACTIONS.lblPointdetail_amount");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["outlet"], "POINTS_TRANSACTIONS.lblPointdetail_outletname");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["property"], "POINTS_TRANSACTIONS.lblPointdetail_propertyname");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["reason"], "POINTS_TRANSACTIONS.lblPointdetail_reason");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.POINTS_TRANSACTIONS_TAB");
                    break;

                case "CompsTransactions":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.COMPS_TRANSACTIONS_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("COMP_TRANSACTIONS.COMP_TANSACTIONS_FRAME");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("COMP_TRANSACTIONS.COMP_TANSACTIONS_ROW", ConvertStringtoTable("Date:" + bucketEarningtab["date"], "PropertyDesc:" + bucketEarningtab["property"], "outlet:" + bucketEarningtab["outlet"], "Description:" + bucketEarningtab["description"], "Status:" + bucketEarningtab["status"], "CostToPalyer:" + bucketEarningtab["cost"], "Type:" + bucketEarningtab["type"]));
                    _iwebstep.GetService().GivenUserClicksOn("COMP_TRANSACTIONS.btnViewcompdetail");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["compstatus"], "COMP_TRANSACTIONS.lblCompdetailstatus");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["outletdescription"], "COMP_TRANSACTIONS.lblCompdetailoutlettype");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["description"], "COMP_TRANSACTIONS.lblCompdetailcompitem");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["property"], "COMP_TRANSACTIONS.lblCompdetailproperty");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["outletname"], "COMP_TRANSACTIONS.lblCompdetailoutlet");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["cost"] + ".00", "COMP_TRANSACTIONS.lblCompdetailIssuedamout");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["issuer"], "COMP_TRANSACTIONS.lblCompdetailIssuedby");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.COMPS_TRANSACTIONS_TAB");
                    break;

                case "DiscompTransactions":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.DISCOMPS_TRANSACTIONS_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("DCOMPS.DCOMPS_FRAME");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("DCOMPS.DCOMPS_TABLE_ROW", ConvertStringtoTable("property:" + bucketEarningtab["property"], "outlet:" + bucketEarningtab["outlet"], "description:" + bucketEarningtab["description"], "status:" + bucketEarningtab["status"], "value:" + bucketEarningtab["value"], "playercost:" + bucketEarningtab["cost"], "type:" + bucketEarningtab["type"]));
                    _iwebstep.GetService().GivenUserClicksOn("COMP_TRANSACTIONS.btnViewcompdetail");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["outlet"], "COMP_TRANSACTIONS.btnViewcompdetail");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", bucketEarningtab["status"], "COMP_TRANSACTIONS.lblCompdetailstatus");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.CLOSE_BUTTON");
                    break;

                case "PromoTransactions":
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
                    _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PROMO_TRANSACTION_TAB");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("PROMO_TRANSACTIONS.PROMO_FRAME");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("PROMO_TRANSACTIONS.PROMO_TRANS_ROW_DATA", ConvertStringtoTable("datetime:" + bucketEarningtab["date"], "property:" + bucketEarningtab["property"], "transtype:" + bucketEarningtab["transaction"], "source:" + bucketEarningtab["source"], "user:" + bucketEarningtab["username"], "amount:" + bucketEarningtab["amount"], "expireson:" + bucketEarningtab["expirydate"], "universal:" + bucketEarningtab["universal"]));
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    break;

                default:
                    throw new AutomationException("Un-Identified Earnings Tabname. Please choose from the provided Earnings Tabname list.");
            }
        }

        [Given(@"Loyalty User verifies player ""(.*)"" Tripdetails having triptype ""(.*)"" and tripevent ""(.*)"" under Trips dashboard with parameters")]
        public void GivenLoyaltyUserVerifiesPlayerTripdetails(string universalPlayer, string triptype, string tripevent, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            tripDetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.TRIPS_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("TRIPS.TRIPS_FRAME");
            switch (tripDetails["tripnumber"])
            {
                case "1":
                    _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripnumber"], "TRIPS.ALL_TOTAL_TRIPS_NUMBER");
                    _iwebstep.GetService().GivenUserClicksOn("TRIPS.TRIP_NUMBER_LINK");

                    break;

                case "2":
                    _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripnumber"], "TRIPS.ALL_TOTAL_TRIPS_NUMBER");
                    _iwebstep.GetService().GivenUserClicksOn("TRIPS.TRIP_NUMBER_LINK");
                    break;

                case "3":
                    _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripnumber"], "TRIPS.ALL_TOTAL_TRIPS_NUMBER");
                    _iwebstep.GetService().GivenUserClicksOn("TRIPS.TRIP_NUMBER_LINK");

                    break;
            }

            if (triptype.Equals("Local"))
            {
                switch (tripevent)
                {
                    case "Balance Adjustment":
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["property"], "TRIPS.RATING_DETAILS_TRIP_PROPERTY");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["issuecomps"], "TRIPS.TRIP_COMPS_ISSUED");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["redeemcomps"], "TRIPS.TRIP_COMPS_REDEEMED");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["pointearned"], "TRIPS.TRIP_POINTS_EARNED");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tierearned"], "TRIPS.TRIP_TIER_CREDITS_EARNED");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripstatus"], "TRIPS.TRIP_STATUS");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripname"], "TRIPS.TRIP_TYPENAME");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["promoearned"], "TRIPS.lblTrip_promoadjustedamt");
                        _iwebstep.GetService().GivenUserClicksOn("TRIPS.RATING_DETAILS_TRIPHISTORY_LINK");
                        _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                        break;

                    case "Rating":
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripname"], "TRIPS.TRIP_TYPENAME");
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripstatus"], "TRIPS.TRIP_STATUS");
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["property"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:PropertyName"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["tripnumber"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:TripNumber"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["rating"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:RatingTypeName"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["station"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:TransStation"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["rating"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:PlayerSessionType"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["uid"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:RatingSourceID"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["locationid"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:LocationID"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["gameid"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:GameID"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["depid"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:DeptID"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["areaid"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:AreaID"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["timeplayed"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:TimePlayed"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["buyin"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:TotalBuyin"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["progessivewin"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:ProgressiveWon"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["actualwin"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:TableActualWin"));
                        _iwebstep.GetService().GivenUserVerifyAttributeParameters("text", tripDetails["theowin"], "TRIPS.lblTripHisValue", ConvertStringtoTable("TripHisValue:TableTheoWin"));
                        _iwebstep.GetService().GivenUserClicksOn("TRIPS.RATING_DETAILS_TRIPHISTORY_LINK");
                        _iwebstep.GetService().GivenUserSwitchesToFrame("default");

                        break;
                    case "Offer Redemption":
                        break;
                    case "Comp Redemption":
                        break;
                    case "Awards Redemption":
                        break;

                }
            }

            else if (triptype.Equals("Lodger"))
            {
                _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["property"], "TRIPS.RATING_DETAILS_TRIP_PROPERTY");
                _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripstatus"], "TRIPS.TRIP_STATUS");
                _iwebstep.GetService().GivenUserVerifyAttribute("text", tripDetails["tripname"], "TRIPS.TRIP_TYPENAME");
                _iwebstep.GetService().GivenUserClicksOn("TRIPS.RATING_DETAILS_TRIPHISTORY_LINK");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            }
            else { }

        }

        [When(@"Loyalty User assign Offer to Player ""(.*)"" with parameters")]
        private void assignOffer(String player, Table parameters)
        {

            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(player, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.OFFERS_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("OFFERS.OFFER_FRAME");
            _iwebstep.GetService().GivenUserClicksOn("OFFERS.ADD_OFFER_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("OFFERS.ADD_OFFER_TABLE", parameters);
            _iwebstep.GetService().GivenUserClicksOnWithParameters("OFFERS.ADD_OFFER_TABLE", parameters);
            _iwebstep.GetService().GivenUserClicksOn("OFFERS.ADD_PLAYER_TO_OFFER_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "OFFERS.AUTHORIZE_PASSWORD_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("1", "OFFERS.AUTHORIZE_REASON_DROPDOWN", "index");
            _iwebstep.GetService().GivenUserEntersText("Test Comments", "OFFERS.AUTHORIZE_COMMENTS_TEXTAREA");
            _iwebstep.GetService().GivenUserClicksOn("OFFERS.AUTHORIZE_SUBMIT_BUTTON");
            _iwebstep.GetService().ThenUserWaits("5");
            _iwebstep.GetService().GivenUserClicksOn("OFFERS.ADDED_MESSAGE_OK_BUTTON");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");

        }


        [When(@"Loyalty User assign Award to Player ""(.*)"" with parameters")]
        private void assignAward(String player, Table parameters)
        {

            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(player, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.AWARDS_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("AWARDS.AWARDS_FRAME");
            _iwebstep.GetService().GivenUserClicksOn("AWARDS.SHOW_TYPES_BUTTON");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("AWARDS.ADD_AWARD_TABLE", parameters);
            _iwebstep.GivenUserClicksOnWithParameters("AWARDS.ADD_AWARD_TABLE", parameters);
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("AWARDS.ADD_AWARD_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("AWARDS.ADD_SUCCESS_MESSAGE_OK_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("AWARDS.CANCEL_ADD_BUTTON");

        }


        [When(@"Loyalty User Issue ""(.*)"" to Player ""(.*)"" with following details")]
        public void IssueComp(String issue, String player, Table datatables)
        {
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(player, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().GivenUserSwitchesToFrame("PLAYER_INFO.INFO_FRAME");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_INFO.ISSUE_COMP_BUTTON");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserSwitchesToFrame("ISSUE_COMP.ISSUE_COMP_FRAME");
            switch (issue)
            {
                case "Comp":
                    _iwebstep.GetService().ThenUserElement("selects", "ISSUE_COMP.COMP_SOURCE_COMP_EARNINGS_RADIOBUTTON");
                    break;
                case "DeComp":
                case "DComp":
                    _iwebstep.GetService().ThenUserElement("selects", "ISSUE_COMP.COMP_SOURCE_DISCRETIONARY_COMP_RADIOBUTTON");
                    break;
            }
            _iwebstep.GetService();
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            compDetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(compDetails["comptype"], "ISSUE_COMP.COMP_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(compDetails["compitem"], "ISSUE_COMP.COMP_ITEM_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserEntersText(compDetails["comps"], "ISSUE_COMP.COMP_COUNT_TEXTBOX");
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('btnIssueComp').click()");
            switch (compDetails["functionautherization"])
            {
                case "Y":
                case "y":
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_PASSWORD_TEXTBOX");
                    _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("1", "ISSUE_COMP.lstCompissuetypereason", "index");
                    _iwebstep.GetService().GivenUserEntersText("Automation", "ISSUE_COMP.txtAreatext");
                    _iwebstep.GetService().GivenUserClicksOn("ISSUE_COMP.btnSubmit");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
                    _iwebstep.GetService().ThenUserWaits("2");
                    _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
                    _iwebstep.GetService().ThenUserWaits("2");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");

                    break;
                case "N":
                case "n":
                    _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
                    _iwebstep.GetService().ThenUserWaits("1");
                    _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
                    _iwebstep.GetService().ThenUserWaits("2");
                    _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                    break;
            }
        }


        [When(@"Loyality User Void Comp with parameter")]
        public void VoidComp(Table datatables)
        {
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.COMPS_TRANSACTIONS_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("COMPS.COMPS_FRAME");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("COMPS.COMPS_TABLE_ROW_VOID", datatables);
            _iwebstep.GetService().GivenUserClicksOn("COMPS.COMPS_VOID_CONFIRM_VOID_BUTTON");
            _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "COMPS.COMPS_VALIDATE_PASSWORD");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("1", "COMPS.COMPS_VALIDATE_REASON", "index");
            _iwebstep.GetService().GivenUserEntersText("Test Comments", "COMPS.COMPS_VALIDATE_COMMENT");
            _iwebstep.GetService().GivenUserClicksOn("COMPS.COMPS_VALIDATE_OK");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserClicksOn("COMPS.COMPS_STATUS_OK");

        }

        [Then(@"EB User verify Player Transaction tab with Parameters")]
        public void EBUserVerifyPlayerTransactionTabwithParameters(Table parameters)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(parameters).Build();
            Transactiontab = _iteststep.GetMultiRowDataTable()[0];
            //Player Dashboard Screen.
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.tab_PlayerTransactions");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(Transactiontab["bucketview"], "TRANSACTIONTAB.BucketView", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            foreach (var item in Transactiontab)
            {
                switch (item.Key)
                {

                    case "outlet":
                        {
                            _iwebstep.GetService().GivenUserClicksOn("TRANSACTIONTAB.FilterExpend");
                            _iwebstep.GetService().ThenUserWaits("2");

                            if (Transactiontab["transactiontype"] == "Adjustment")
                            {
                               // TBD
                            }
                            else
                            {
                               
                                _iwebstep.GetService().GivenUserClicksOn("TRANSACTIONTAB.FilterOutlet");
                                _iwebstep.GetService().ThenUserWaits("1");
                                _iwebstep.GetService().GivenUserEntersText(Transactiontab["outlet"], "TRANSACTIONTAB.OutletDrop_Search");
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().GivenUserClicksOnWithParameters("TRANSACTIONTAB.DropdownOption", ConvertStringtoTable("option:" + Transactiontab["outlet"]));
                                _iwebstep.GetService().ThenUserWaits("2");
                            }
                            break;
                        }
                    case "duration":
                        {

                            if (Transactiontab["duration"] == "Custom")
                            {
                                _iwebstep.GetService().GivenUserClicksOn("TRANSACTIONTAB.DateRangeExpend");
                                _iwebstep.GetService().GivenUserEntersText("Custom", "TRANSACTIONTAB.DateRangeFilter");
                                _iwebstep.GetService().GivenUserClicksOn("TRANSACTIONTAB.dateRangeCustomOption");
                                _iwebstep.GetService().ThenUserWaits("2");
                                _iwebstep.GetService().GivenUserEntersText(Transactiontab["from date"], "TRANSACTIONTAB.FilterStartDate");
                                _iwebstep.GetService().ThenUserWaits("1");
                                _iwebstep.GetService().GivenUserEntersText(Transactiontab["to date"], "TRANSACTIONTAB.FilterEndDate");
                                _iwebstep.GetService().ThenUserWaits("1");

                            }
                            else
                            {
                                _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(item.Value, "TRANSACTIONTAB.DateRange", "visibletext");

                            }
                            break;
                        }
                }
            }
            _iwebstep.GetService().GivenUserClicksOn("TRANSACTIONTAB.FilterGetResult");
            _iwebstep.GetService().ThenUserWaits("2");

            //Validating if transaction is of Comp Type
            if (Transactiontab.ContainsKey("comp amount"))
            {
                _iwebstep.GetService().ThenUserVerifiesElementWithParameters("MANAGE_EXTEND_BUCKET.mic_TransactionTab_GridRow_Comp", "true", ConvertStringtoTable("TransactionDate:" + Transactiontab["transactiondto"], "Property:" + Transactiontab["property"], "Outlet:" + Transactiontab["outlet"], "User:" + Transactiontab["user"], "TransactionType:" + Transactiontab["transactiontype"], "Status:" + Transactiontab["status"], "CompAmount:" + Transactiontab["comp amount"]));
                _iwebstep.GetService().GivenUserClicksOnWithParameters("TRANSACTIONTAB.GridrowLink", ConvertStringtoTable("Date:" + Transactiontab["transactiondto"]));
                _iwebstep.GetService().ThenUserWaits("2");
                //Validating Comp Type Adjustment.
                if (Transactiontab.ContainsValue("Adjustment"))
                {
                    //Future currency can be add here.
                    //string[] separator = { "$" };
                    //String[] x = Transactiontab["comp amount"].Split(separator, System.StringSplitOptions.RemoveEmptyEntries);
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["status"], "TRANSACTIONTAB.txt_ViewDetail_Transaction Type");
                    _iwebstep.GetService().ThenUserVerifiesElementWithParameters("TRANSACTIONTAB.IssueDateParam", "true", ConvertStringtoTable("transactiondto:" + Transactiontab["transactiondto"]));
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["comp amount"], "TRANSACTIONTAB.txt_ViewDetail_Issued Amount");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["user"], "TRANSACTIONTAB.txt_ViewDetail_Issued By");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["property"], "TRANSACTIONTAB.txt_ViewDetail_Property");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["status"], "TRANSACTIONTAB.txt_ViewDetail_Status");
                    if (Transactiontab.ContainsKey("reason"))
                    {
                        _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["reason"], "TRANSACTIONTAB.txt_ViewDetail_Reason");
                        _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["comment"], "TRANSACTIONTAB.txt_ViewDetail_Comment");
                    }
                    _iwebstep.GetService().GivenUserClicksOn("TRANSACTIONTAB.btn_ViewDetail_close");
                }
                else
                {
                    //Validating if Comp Type Transaction Issue, redeem, Void
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["outlet type"], "TRANSACTIONTAB.txt_ViewDetail_Outlettype");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["comp item"], "TRANSACTIONTAB.txt_ViewDetail_Compitem");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["status"], "TRANSACTIONTAB.txt_ViewDetail_Transaction Type");
                    _iwebstep.GetService().ThenUserVerifiesElementWithParameters("TRANSACTIONTAB.IssueDateParam", "true", ConvertStringtoTable("transactiondto:" + Transactiontab["issue date"]));
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["comp amount"], "TRANSACTIONTAB.txt_ViewDetail_Issued Amount");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["user"], "TRANSACTIONTAB.txt_ViewDetail_Issued By");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["property"], "TRANSACTIONTAB.txt_ViewDetail_Property");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["outlet"], "TRANSACTIONTAB.txt_ViewDetailOutletName");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["voided by"], "TRANSACTIONTAB.txt_ViewDetai_Voided BY");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["comp value"], "TRANSACTIONTAB.txt_ViewDetail_comp Value");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["status"], "TRANSACTIONTAB.txt_ViewDetail_Status");
                    _iwebstep.GetService().ThenUserVerifiesElementWithParameters("TRANSACTIONTAB.RedeemDateParam", "true", ConvertStringtoTable("redeemdate:" + Transactiontab["redeem date"]));
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["redeemed amount"], "TRANSACTIONTAB.txt_ViewDetail_Redeem Amount");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["redeemed by"], "TRANSACTIONTAB.txt_ViewDetail_Redeemed By");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["comp remaining"], "TRANSACTIONTAB.txt_ViewDetail_Comp Remaing");
                    _iwebstep.GetService().ThenUserVerifiesElementWithParameters("TRANSACTIONTAB.ExpirationDateParam", "true", ConvertStringtoTable("expirationdate:" + Transactiontab["expiration date"]));
                    _iwebstep.GetService().ThenUserVerifiesElementWithParameters("TRANSACTIONTAB.VoidedDateParam", "true", ConvertStringtoTable("voideddate:" + Transactiontab["voided date"]));
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["cost to player"], "TRANSACTIONTAB.txt_ViewDetail_Cost to player");
                    if (Transactiontab.ContainsKey("reason"))
                    {
                        _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["reason"], "TRANSACTIONTAB.txt_ViewDetail_Reason");
                        _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["comment"], "TRANSACTIONTAB.txt_ViewDetail_Comment");
                    }
                    _iwebstep.GetService().GivenUserClicksOn("TRANSACTIONTAB.btn_ViewDetail_close");

                }

            }
            else
            {
                //Validating Non Comp Transaction Adjustment.
                _iwebstep.GetService().ThenUserVerifiesElementWithParameters("MANAGE_EXTEND_BUCKET.mic_TransactionTab_Grid_NonComp", "true", ConvertStringtoTable("Date:" + Transactiontab["transactiondto"], "Property:" + Transactiontab["property"], "Outlet:" + Transactiontab["outlet"], "User:" + Transactiontab["user"], "TransactionType:" + Transactiontab["transactiontype"],"Status:" + Transactiontab["status"], "Amount:" + Transactiontab["amount"], "Value:" + Transactiontab["value"]));
                _iwebstep.GetService().GivenUserClicksOnWithParameters("TRANSACTIONTAB.nonComp_GridrowLink", ConvertStringtoTable("Date:" + Transactiontab["transactiondto"]));
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["transactiontype"], "TRANSACTIONTAB.Tct_ViewDetails_nonCTrxType");
                _iwebstep.GetService().ThenUserVerifiesElementWithParameters("TRANSACTIONTAB.TransDateParam", "true", ConvertStringtoTable("transactiondto:" + Transactiontab["transactiondto"]));
                _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["amount"], "TRANSACTIONTAB.txt_ViewDetail_Amount");
                _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["outlet"], "TRANSACTIONTAB.txt_ViewDetail_Outlet/EGM");
                //Gaming Date
                _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["property"], "TRANSACTIONTAB.txt_ViewDetail_Property Name");
                if (Transactiontab.ContainsKey("bucket"))
                {
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["bucket"], "TRANSACTIONTAB.txt_ViewDetail_Bucket");
                }
                else
                {
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["bucketview"], "TRANSACTIONTAB.txt_ViewDetail_Bucket");
                }
                if (Transactiontab.ContainsKey("reason"))
                {
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["reason"], "TRANSACTIONTAB.txt_ViewDetail_Reason_NonComp");
                    _iwebstep.GetService().GivenUserVerifyAttribute("value", Transactiontab["comment"], "TRANSACTIONTAB.txt_ViewDetail_Comment_NonComp");
                }
                _iwebstep.GetService().GivenUserClicksOn("TRANSACTIONTAB.btn_ViewDetail_NonComp_close");
            }
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
        }


        [Then(@"EB user verify balance by ""(.*)"" at Bucket Balance Popup with Parameters")]
        public void EBUserverifybucketbalancepopup(String type, Table parameters)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(parameters).Build();
            balance = _iteststep.GetMultiRowDataTable()[0];
            String cbalance = string.Empty;
            String fbalance = string.Empty;
            //Moving to the Bucket balance Popup.
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.VIEW_BUCKET_BALANCES");
            _iwebstep.GetService().GivenUserSwitchesToFrame("VIEW_BUCKET_BALANCE.BUCKET_BALANCES_FRAME");
            _iwebstep.GetService().ThenUserWaits("2");
            //Type is group By Bucket
            if(type.ToLower() == "group by bucket")
            {
                
                if(balance.ContainsKey("property"))
                {
                    _iwebstep.GetService().GivenUserClicksOn("VIEW_BUCKET_BALANCE.GroupBy_DDLButton");
                    _iwebstep.GetService().ThenUserWaits("1");
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("VIEW_BUCKET_BALANCE.GroupBy_SortText", ConvertStringtoTable("sorttext:" + balance["property"]));
                    
                }
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserClicksOn("VIEW_BUCKET_BALANCE.SearchTextBox");
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().WhenUserClears("VIEW_BUCKET_BALANCE.SearchTextBox");
                _iwebstep.GetService().GivenUserEntersText(balance["bucketview"], "VIEW_BUCKET_BALANCE.SearchTextBox");
                _iwebstep.GetService().WhenUserPressKey("enter");
                //Consolidated Bucket View
                if(balance.ContainsKey("bucket"))
                {
                    //Consolidated bucket view balance is 00 then bucket view name will be a Text
                    if(balance["amount"] == "0")
                    {
                        _iwebstep.GetService().ThenUserWaits("2");
                        _iwebstep.GetService().GivenUserGetsAttributeValueOfElementWithParametersToSaveWithKey("innerText", "VIEW_BUCKET_BALANCE.DefaultBucketViewBalance", cbalance, ConvertStringtoTable("BucketView:" + balance["bucketview"]));
                    }
                    else
                    {
                        _iwebstep.GetService().ThenUserWaits("2");
                        //Consolidated bucket view have balance it will become a link
                        _iwebstep.GetService().GivenUserClicksOnWithParameters("VIEW_BUCKET_BALANCE.ConsolidatedBucket", ConvertStringtoTable("BucketView:" + balance["bucketview"]));
                        _iwebstep.GetService().ThenUserWaits("2");
                        _iwebstep.GetService().GivenUserGetsAttributeValueOfElementWithParametersToSaveWithKey("innerText", "VIEW_BUCKET_BALANCE.ConsBVBucketBalance", cbalance, ConvertStringtoTable("TBucket:" + balance["bucket"]));
                    }
                }
                else
                {
                    _iwebstep.GetService().ThenUserWaits("2");
                    _iwebstep.GetService().GivenUserGetsAttributeValueOfElementWithParametersToSaveWithKey("innerText", "VIEW_BUCKET_BALANCE.DefaultBucketViewBalance", cbalance, ConvertStringtoTable("BucketView:" + balance["bucketview"]));
                }              

            }
            //Type is bucket by property
            else if(type.ToLower() == "group by property")
            {
                _iwebstep.GetService().GivenUserClicksOn("VIEW_BUCKET_BALANCE.EB_GroupByProperty");
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserClicksOn("VIEW_BUCKET_BALANCE.GroupBy_DDLButton");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserClicksOnWithParameters("VIEW_BUCKET_BALANCE.GroupBy_SortText", ConvertStringtoTable("sorttext:" + balance["bucketview"]));
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserClicksOn("VIEW_BUCKET_BALANCE.SearchTextBox");
                _iwebstep.GetService().GivenUserEntersText(balance["property"], "VIEW_BUCKET_BALANCE.SearchTextBox");
                _iwebstep.GetService().WhenUserPressKey("enter");
                for (int i = 3; i <= 5; i++)
                {
                    String bucket = string.Empty;
                    Table table = new Table(new string[] { "Key", "Value" });
                    table.AddRow(new string[] { "Column", i+"" });
                    _iwebstep.GetService().ThenUserWaits("2");
                    _iwebstep.GetService().GivenUserGetsAttributeValueOfElementWithParametersToSaveWithKey("innerText", "VIEW_BUCKET_BALANCE.GridColumnBucket", bucket, table);
                    String bucketname =  _itestbasemanager.GetTestBase().GetTestDataUsingKey(bucket);
                    //Applied loop on header of grid and iterate till bucket column.
                    if(bucketname.Equals(balance["bucket"]))
                    {
                        _iwebstep.GetService().ThenUserWaits("2");
                        _iwebstep.GetService().GivenUserGetsAttributeValueOfElementWithParametersToSaveWithKey("innerText", "VIEW_BUCKET_BALANCE.GridBucketbal", cbalance, table);
                        break;
                    }
                }

            }
            //validating the balnce on Ui with expected balance.
            fbalance = _itestbasemanager.GetTestBase().GetTestDataUsingKey(cbalance);
            _iwebstep.GetService().GivenUserPerformStringOperations("stringEquals", fbalance, balance["amount"]);
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.Popup_Close");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserPerformActionBrowser("refresh");

        }

        [Then(@"EB User verify Earnings tab with Parameters")]
        public void EBUserverifyEarningstab(Table parameters)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(parameters).Build();
            Earningtab = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.EB_Earning_Menu_Option");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.EB_PlayerEarning");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("EB_Earnings.EB_EARNING_BUCKET_DROPDOWN");
            _iwebstep.GetService().GivenUserClicksOn("EB_Earnings.EB_EARNING_BUCKET_DROPDOWN_SEARCHBOX");
            _iwebstep.GetService().GivenUserEntersText(Earningtab["bucketview"], "EB_Earnings.EB_EARNING_BUCKET_DROPDOWN_SEARCHBOX");
            _iwebstep.GetService().WhenUserPressKey("enter");
            _iwebstep.GetService().GivenUserClicksOn("EB_Earnings.FilterExpand");
            _iwebstep.GetService().ThenUserWaits("2");
            foreach (var item in Earningtab)
            {
                switch (item.Key)
                {
                    case "property":
                    {
                            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(item.Value, "EB_Earnings.EB_PropertyFilter", "visibletext");
                            break;
                    }
                    case "transactiontype":
                    {
                            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(item.Value, "EB_Earnings.EB_TrxTypeFilter", "visibletext");
                            break;
                    }
                    case "rewardrule":
                    {
                            _iwebstep.GetService().GivenUserSelectsOptionOfElementBy(item.Value, "EB_Earnings.EB_RwrdRuleFilter", "visibletext");
                            break;
                    }
                    case "fromdate":
                    {
                            _iwebstep.GetService().GivenUserEntersText(item.Value, "EB_Earnings.EB_FromDateFilter");
                            break;
                    }
                    case "todate":
                     {
                            _iwebstep.GetService().GivenUserEntersText(item.Value, "EB_Earnings.EB_ToDateFilter");
                            break;
                     }

                }
              
            }
            _iwebstep.GetService().GivenUserClicksOn("EB_Earnings.GetResultButton");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("EB_Earnings.ExpandGridTrx", ConvertStringtoTable("gamingdate:" + Earningtab["gamingdate"]));
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("EB_Earnings.EB_Expand_Earning_Row", ConvertStringtoTable("Property:" + Earningtab["property"], "RatingType:" + Earningtab["transactiontype"], "Amount:" + Earningtab["amount"], "RewardRule:" + Earningtab["rewardrule"]));
            _iwebstep.GetService().GivenUserClicksOnWithParameters("EB_Earnings.EarningRow_Link", ConvertStringtoTable("Property:" + Earningtab["property"], "RatingType:" + Earningtab["transactiontype"], "Amount:" + Earningtab["amount"], "RewardRule:" + Earningtab["rewardrule"], "TransactionDate:" + Earningtab["transactiondate"]));
            _iwebstep.GetService().ThenUserWaits("2");
            //Validating information at Earning deatails popup.
            _iwebstep.GetService().GivenUserVerifyAttribute("innerText", Earningtab["property"], "EB_Earnings.EARNING_DETAILS_Property");
            //If Consolidated Bucket view.
            if(Earningtab.ContainsKey("bucket"))
            {
                _iwebstep.GetService().GivenUserVerifyAttribute("innerText", Earningtab["bucket"], "EB_Earnings.EARNING_DETAILS_Bucket");

            }
            //If default Bucket view.
            else
            {
             _iwebstep.GetService().GivenUserVerifyAttribute("innerText", Earningtab["bucketview"], "EB_Earnings.EARNING_DETAILS_Bucket");
            }
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("EB_Earnings.EARNING_DETAILS_Date", "true", ConvertStringtoTable("TransactionDate:" + Earningtab["transactiondate"]));
            _iwebstep.GetService().GivenUserVerifyAttribute("innerText", Earningtab["transactiontype"], "EB_Earnings.EARNING_DETAILS_Transactiontype");
            _iwebstep.GetService().GivenUserVerifyAttribute("innerText", Earningtab["amount"], "EB_Earnings.EARNING_DETAILS_Amount");
            _iwebstep.GetService().GivenUserVerifyAttribute("innerText", Earningtab["rewardrule"], "EB_Earnings.EARNING_DETAILS_Rule");
            _iwebstep.GetService().GivenUserClicksOn("EB_Earnings.EarningDetailsClose");
        }
        
    }

}

