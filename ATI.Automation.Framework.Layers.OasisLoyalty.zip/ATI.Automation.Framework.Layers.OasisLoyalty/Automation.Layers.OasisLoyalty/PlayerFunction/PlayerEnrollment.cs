﻿using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.WebAbstraction;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty
{

    // This will hold all step definitions of Web related to Enrollment.
    [Binding]
    public class PlayerEnrollment : LoyaltyBase
    {
        Dictionary<string, string> fetchOfferdetails = new Dictionary<string, string>();
        Dictionary<string, string> editPersonalPatronDetail = new Dictionary<string, string>();
        Dictionary<string, string> editAddressPatronDetail = new Dictionary<string, string>();
        Dictionary<string, string> editTelephonePatronDetail = new Dictionary<string, string>();
        Dictionary<string, string> editEmailPatronDetail = new Dictionary<string, string>();
        Dictionary<string, string> editSocialPatronDetail = new Dictionary<string, string>();
        Dictionary<string, string> editSmsPatronDetail = new Dictionary<string, string>();
        Dictionary<string, string> playerDetails = new Dictionary<string, string>();

        ITestStepBuilder _iteststepbuilder;

        ITestStep _iteststep;
        IWebStepDef _iwebstep;


        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();
        }



         [When(@"Loyalty User Enroll Player via Webapp with ""(.*)"" name and save key ""(.*)"" with data")]
           public void EnrollPlayerWebapp(String fname, String player_ID, Table table)
        {
            String query = "select P.PropertyName from  UC_X_ADGroupPropXref AGP, UC_U_ADGroup AG, UC_X_Property P where AGP.ADGroupID = AG.ADGroupID and AGP.PropertyID = P.PropertyID and AGP.ActiveFlag = 1 and AGP.DefaultFlag = 1 and AG.ADGroupName = '<#Halo_ADGroup#>'";
            _iwebstep.GetService().GivenUserRunsQuery(query, "<#Halo_db_connectionstring#>", "PropertyName");
            query = "select P.PropertyID from  UC_X_Property P where PropertyName = '<$PropertyName$>'";
            _iwebstep.GetService().GivenUserRunsQuery(query, "<#Halo_db_connectionstring#>", "PropertyID");
            query = "select Top 1 EmailType from UC_X_EmailType where Active =1 and PropertyID = '<$PropertyID$>'";
            _iwebstep.GetService().GivenUserRunsQuery(query, "<#Halo_db_connectionstring#>", "EmailType");
            _iwebstep.GetService().GivenUserRunsQuery("select Top 1 SmsType from UC_X_SmsType where Active=1", "<#Halo_db_connectionstring#>", "SMSType");
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            playerDetails = _iteststep.GetMultiRowDataTable()[0];

            _iwebstep.GetService().GivenUserEntersText("Enroll Player", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ENROLL_PLAYER");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Standard", "ENROLL_PLAYER.ENROLL_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("SIR", "ENROLL_PLAYER.ID_PREFIX_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserEntersText(fname, "ENROLL_PLAYER.ID_FIRST_NAME_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("M", "ENROLL_PLAYER.ID_MIDDLE_NAME_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("LastName", "ENROLL_PLAYER.ID_LAST_NAME_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("JR", "ENROLL_PLAYER.ID_SUFFIX_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserEntersText(playerDetails["birthdate"], "ENROLL_PLAYER.ID_BDAY_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(playerDetails["gender"], "ENROLL_PLAYER.ID_PLAYER_GENDER_DROPDOWN", "visibletext");
            //Identification
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(playerDetails["identificationtype"], "ENROLL_PLAYER.ID_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("TUVXYZ54322", "ENROLL_PLAYER.ID_TEXT_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(playerDetails["birthdate"], "ENROLL_PLAYER.ID_DOB_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("10/12/2030", "ENROLL_PLAYER.ID_EXPIRY_DATE_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("United States", "ENROLL_PLAYER.ID_COUNTRY_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ENROLL_PLAYER.ID_STATE_DROPDOWN");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Florida", "ENROLL_PLAYER.ID_STATE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Australian", "ENROLL_PLAYER.ID_NATIONALITY_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(playerDetails["gender"], "ENROLL_PLAYER.ID_GENDER_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            //Address Information
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.ADDRESS_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Mail", "ENROLL_PLAYER.ADDRESS_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("Test Address", "ENROLL_PLAYER.ADDRESS_LINE1_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("Test Address2", "ENROLL_PLAYER.ADDRESS_LINE2_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("SAINT PETERSBURG", "ENROLL_PLAYER.ADDRESS_CITY_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("United States", "ENROLL_PLAYER.ADDRESS_COUNTRY_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Florida", "ENROLL_PLAYER.ADDRESS_STATE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("33701", "ENROLL_PLAYER.ADDRESS_ZIPCODE_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("2346", "ENROLL_PLAYER.ADDRESS_ZIP_PLUS_FOUR_TEXTBOX");
            // select phone status
            _iwebstep.GetService().ThenUserWaits("2");           
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Primary", "ENROLL_PLAYER.TELEPHONE_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserEntersText("9977553311", "ENROLL_PLAYER.TELEPHONE_NUMBER_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Yes", "ENROLL_PLAYER.TELEPHONE_STATUS_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.TELEPHONE_OPTIN_CHECKBOX");
            // select Email status
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.EMAIL_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("<$EmailType$>", "ENROLL_PLAYER.EMAIL_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("abc@a.com", "ENROLL_PLAYER.EMAIL_ADDRESS_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ENROLL_PLAYER.EMAIL_STATUS_DROPDOWN");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Yes", "ENROLL_PLAYER.EMAIL_STATUS_DROPDOWN", "visibletext");
            // select mail status
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.SOCIAL_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Gmail", "ENROLL_PLAYER.SOCIAL_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("test2@gmail.com", "ENROLL_PLAYER.SOCIAL_ACCOUNT_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ENROLL_PLAYER.drpdwn_SocialStatus");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Yes", "ENROLL_PLAYER.drpdwn_SocialStatus", "visibletext");
            // select social status  
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.SMS_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("<$SMSType$>", "ENROLL_PLAYER.SMS_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText("9977553311", "ENROLL_PLAYER.SMS_ACCOUNT_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ENROLL_PLAYER.drpdwn_SmsStatus");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Yes", "ENROLL_PLAYER.drpdwn_SmsStatus", "visibletext");
            // select SMS status
            _iwebstep.GetService().GivenUserEntersText("1836", "ENROLL_PLAYER.PIN_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("1836", "ENROLL_PLAYER.PIN_AGAIN_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("ENROLL_PLAYER.GLOBAL_SOCIAL_RADIOBUTTON");
            _iwebstep.GetService().GivenUserClicksOn("ENROLL_PLAYER.ENROLL_BUTTON");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserRunsQuery("select UniversalPlayerID from uc_pl_player where FirstName = '" + fname + "'", "<#Halo_db_connectionstring#>", player_ID);


           
        }

        [When(@"Loyalty User update Identification on EditPatron screen with parameter")]
        public void EditIdentificationPatronData(Table datatables)
        {

            _iwebstep.GetService();
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            editPersonalPatronDetail = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.EDIT_PATRON_DATA");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ID_FIRST_NAME_TEXTBOX");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ID_MIDDLE_NAME_TEXTBOX");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ID_LAST_NAME_TEXTBOX");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ID_BDAY_TEXTBOX");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ID_TEXT_TEXTBOX");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ID_DOB_TEXTBOX");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ID_EXPIRY_DATE_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editPersonalPatronDetail["fname"], "ENROLL_PLAYER.ID_FIRST_NAME_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editPersonalPatronDetail["mname"], "ENROLL_PLAYER.ID_MIDDLE_NAME_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editPersonalPatronDetail["lname"], "ENROLL_PLAYER.ID_LAST_NAME_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editPersonalPatronDetail["sufix"], "ENROLL_PLAYER.ID_SUFFIX_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserEntersText(editPersonalPatronDetail["bdate"], "ENROLL_PLAYER.ID_BDAY_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editPersonalPatronDetail["gender"], "ENROLL_PLAYER.ID_PLAYER_GENDER_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editPersonalPatronDetail["idtype"], "ENROLL_PLAYER.ID_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText(editPersonalPatronDetail["idnumber"], "ENROLL_PLAYER.ID_TEXT_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editPersonalPatronDetail["bdate"], "ENROLL_PLAYER.ID_DOB_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editPersonalPatronDetail["expdate"], "ENROLL_PLAYER.ID_EXPIRY_DATE_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editPersonalPatronDetail["country"], "ENROLL_PLAYER.ID_COUNTRY_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editPersonalPatronDetail["state"], "ENROLL_PLAYER.ID_STATE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editPersonalPatronDetail["nationality"], "ENROLL_PLAYER.ID_NATIONALITY_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");

            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.SAVE_BTN");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_ENROLL_CONFIG.SAVE_BTN");

        }



        [When(@"Loyalty User create enrollment ""(.*)"" with data")]
        public void CreateEnrollmentType(String enrollmentName, Table datatables)
        {

            String query = "select P.PropertyName from  UC_X_ADGroupPropXref AGP, UC_U_ADGroup AG, UC_X_Property P where AGP.ADGroupID = AG.ADGroupID and AGP.PropertyID = P.PropertyID and AGP.ActiveFlag = 1 and AGP.DefaultFlag = 1 and AG.ADGroupName = '<#Halo_ADGroup#>'";
            _iwebstep.GetService().GivenUserRunsQuery(query, "<#Halo_db_connectionstring#>", "PropertyName");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADMINISTRATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.CONFIGURE_ENROLLMENT_LINK");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_ENROLL_CONFIG.btnAddNewEnrollmentType");
            _iwebstep.GetService().GivenUserEntersText(enrollmentName, "PLAYER_ENROLL_CONFIG.ENROLLMENT_NAME_TXT_BX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("<$PropertyName$>", "PLAYER_ENROLL_CONFIG.PROPERTY_DROP_DWN", "visibletext");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Standard", "PLAYER_ENROLL_CONFIG.drpdwnAccountType", "visibletext");

            _iwebstep.GetService();
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            fetchOfferdetails = _iteststep.GetMultiRowDataTable()[0];

            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:PlayerIdentity1", "condition:" + fetchOfferdetails["playeridentity1"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:PlayerIdentity2", "condition:" + fetchOfferdetails["playeridentity2"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:Gender", "condition:" + fetchOfferdetails["gender"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:Occupation", "condition:" + fetchOfferdetails["occupation"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:Identification", "condition:" + fetchOfferdetails["identification"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:Address", "condition:" + fetchOfferdetails["address"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:Telephone", "condition:" + fetchOfferdetails["telephone"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:Email", "condition:" + fetchOfferdetails["email"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:Social", "condition:" + fetchOfferdetails["social"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:SMS", "condition:" + fetchOfferdetails["sms"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:PIN", "condition:" + fetchOfferdetails["pin"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:SSN", "condition:" + fetchOfferdetails["ssn"]));
            _iwebstep.GetService().ThenUserClicksWithoutDelayOnWithParameters("PLAYER_ENROLL_CONFIG.rdbEnrollmentTypeInfoItem", ConvertStringtoTable("infoItem:EnrollProp", "condition:" + fetchOfferdetails["enrollprop"]));
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_ENROLL_CONFIG.SAVE_BTN");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("PLAYER_ENROLL_CONFIG.txtEnrollmentCreatedMsg", ConvertStringtoTable("EnrollmentMsg:Enrollment type successfully saved"));


        }


        [When(@"Loyalty User update Address on EditPatron screen with parameter")]
        public void EditAddressPatronData(Table datatables)
        {

            _iwebstep.GetService();
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            editAddressPatronDetail = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.EDIT_PATRON_DATA");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.ADDRESS_OPTIN_CHECKBOX");
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.ADDRESS_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editAddressPatronDetail["addresstype"], "ENROLL_PLAYER.ADDRESS_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ADDRESS_LINE1_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editAddressPatronDetail["addressline1"], "ENROLL_PLAYER.ADDRESS_LINE1_TEXTBOX");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ADDRESS_LINE2_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editAddressPatronDetail["AddressLine2"], "ENROLL_PLAYER.ADDRESS_LINE2_TEXTBOX");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ADDRESS_CITY_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editAddressPatronDetail["city"], "ENROLL_PLAYER.ADDRESS_CITY_TEXTBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editAddressPatronDetail["country"], "ENROLL_PLAYER.ADDRESS_COUNTRY_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editAddressPatronDetail["state"], "ENROLL_PLAYER.ADDRESS_STATE_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.ADDRESS_ZIPCODE_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editAddressPatronDetail["zip"], "ENROLL_PLAYER.ADDRESS_ZIPCODE_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText("2346", "ENROLL_PLAYER.ADDRESS_ZIP_PLUS_FOUR_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.SAVE_BTN");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_ENROLL_CONFIG.SAVE_BTN");

        }

        [When(@"Loyalty User update Telephone on EditPatron screen with parameter")]
        public void EditTelephonePatronData(Table datatables)
        {

            _iwebstep.GetService();
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            editTelephonePatronDetail = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.EDIT_PATRON_DATA");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.TELEPHONE_OPTIN_CHECKBOX");

            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.TELEPHONE_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editTelephonePatronDetail["telephonetype"], "ENROLL_PLAYER.TELEPHONE_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.TELEPHONE_NUMBER_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editTelephonePatronDetail["telephonenumber"], "ENROLL_PLAYER.TELEPHONE_NUMBER_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editTelephonePatronDetail["status"], "ENROLL_PLAYER.TELEPHONE_STATUS_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.SAVE_BTN");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_ENROLL_CONFIG.SAVE_BTN");

        }

        [When(@"Loyalty User update Email on EditPatron screen with parameter")]
        public void EditEmailPatronData(Table datatables)
        {

            _iwebstep.GetService();
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            editEmailPatronDetail = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.EDIT_PATRON_DATA");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.EMAIL_OPTIN_CHECKBOX");
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.EMAIL_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editEmailPatronDetail["emailtype"], "ENROLL_PLAYER.EMAIL_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.EMAIL_ADDRESS_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editEmailPatronDetail["emailaddress"], "ENROLL_PLAYER.EMAIL_ADDRESS_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editEmailPatronDetail["status"], "ENROLL_PLAYER.EMAIL_STATUS_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.SAVE_BTN");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_ENROLL_CONFIG.SAVE_BTN");

        }


        [When(@"Loyalty User update Social on EditPatron screen with parameter")]
        public void EditSocialPatronData(Table datatables)
        {

            _iwebstep.GetService();
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            editSocialPatronDetail = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.EDIT_PATRON_DATA");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.SOCIAL_OPTIN_CHECKBOX");
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.SOCIAL_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editSocialPatronDetail["socialtype"], "ENROLL_PLAYER.SOCIAL_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.SOCIAL_ACCOUNT_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editSocialPatronDetail["socialaccount"], "ENROLL_PLAYER.SOCIAL_ACCOUNT_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editSocialPatronDetail["status"], "ENROLL_PLAYER.drpdwn_SocialStatus", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.SAVE_BTN");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_ENROLL_CONFIG.SAVE_BTN");

        }


        [When(@"Loyalty User update Sms on EditPatron screen with parameter")]
        public void EditSmsPatronData(Table datatables)
        {

            _iwebstep.GetService();
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
            editSmsPatronDetail = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.EDIT_PATRON_DATA");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.SMS_OPTIN_CHECKBOX");
            _iwebstep.GetService().ThenUserElement("checks", "ENROLL_PLAYER.SMS_OPTIN_CHECKBOX");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editSmsPatronDetail["smstype"], "ENROLL_PLAYER.SMS_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().WhenUserClears("ENROLL_PLAYER.SMS_ACCOUNT_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(editSmsPatronDetail["smsaccount"], "ENROLL_PLAYER.SMS_ACCOUNT_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(editSmsPatronDetail["status"], "ENROLL_PLAYER.drpdwn_SmsStatus", "visibletext");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserScrollTillElementWithParameters("PLAYER_ENROLL_CONFIG.SAVE_BTN");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_ENROLL_CONFIG.SAVE_BTN");

        }











    }
}
