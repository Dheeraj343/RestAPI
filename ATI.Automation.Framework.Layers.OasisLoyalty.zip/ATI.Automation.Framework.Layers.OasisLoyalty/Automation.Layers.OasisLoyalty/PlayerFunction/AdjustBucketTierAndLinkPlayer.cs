﻿using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.WebAbstraction;
using Automation.Framework.Exceptions;
using AventStack.ExtentReports.Gherkin.Model;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty
{
    [Binding]
    public class AdjustBucketTierAndLinkPlayer : LoyaltyBase
    {
        ITestStepBuilder _iteststepbuilder;
        ITestStep _iteststep;
        IWebStepDef _iwebstep;
        ITestBaseManager _itestbasemanager;
        Dictionary<string, string> fetchBucketAdjustmentdetails = new Dictionary<string, string>();
        Dictionary<string, string> adjustTierlevel = new Dictionary<string, string>();
        Dictionary<string, string> BucketAdjustmentdetails = new Dictionary<string, string>();
        Dictionary<string, string> linkplayerdetails = new Dictionary<string, string>();
        String expiredate = "";

        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();
            _itestbasemanager = Cucumber._serviceprovider.GetService<ITestBaseManager>();

        }


        public string SoapRequest(string url, string action, string requestcontent)
        {
            throw new NotImplementedException();
        }

        public string GetValueFromSoapResponse(string xmlresponse, string node, string attribute, string query)
        {
            throw new NotImplementedException();
        }
        private void updateFuncauthstatus(string overridetype, int flag)
        {
            String query = "Update UC_X_OverrideType set ShowPassword = " + flag + ", RequirePassword = " + flag + ", ShowReason = " + flag + ", RequireReason = " + flag + ", ShowComment = " + flag + ", RequireComment = " + flag + " where OverrideType like " + "'" + overridetype + "'" + "";
            _iwebstep.GetService().GivenUserExecutesQuery(query, "<#Halo_db_connectionstring#>");
        }

        [When(@"Loyalty User link player ""(.*)"" and ""(.*)"" with link Type ""(.*)""")]
        private void LinkPlayer(String player1, String player2, String linkType)
        {
            _iwebstep.GetService().GivenUserRunsQuery("select Top 1 LinkPlayerReason from UC_X_LinkedPlayerReason where Active =1", "<#Halo_db_connectionstring#>", "LinkPlayerReason");
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(player1, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.LINK_PLAYER_LINK");
            _iwebstep.GetService().GivenUserSwitchesToFrame("LINK_PLAYER_POPUP.LINK_PLAYER_FRAME");
            _iwebstep.GetService().GivenUserEntersText(player2, "LINK_PLAYER_POPUP.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("LINK_PLAYER_POPUP.PLAYER_LOOKUP_IMAGE");
            _iwebstep.GivenUserSelectsOptionsOfElementBy(linkType, "LINK_PLAYER_POPUP.LINK_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("LINK_PLAYER_POPUP.OK_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_PASSWORD_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("<$LinkPlayerReason$>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_LINK_REASON", "visibletext");
            _iwebstep.GetService().GivenUserEntersText("Automation Test", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_COMMENT_TEXTAREA");
            _iwebstep.GetService().GivenUserClicksOn("AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_SUBMIT");
            _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");

        }

        [When(@"Loyalty User adjust bucket ""(.*)"" with function Authorization check ""(.*)"" with parameters")]
        public void WhenLoyaltyUserAdjustBucketWithFunctionAuthorization(string bucketname, string functionauthCheck, Table table)
        {

            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADJUST_BUCKET_VALUE");
            _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(bucketname, "ADJUST_BUCKET_VALUE_POPUP.BUCKET_TYPE_DROPDOWN", "visibletext");
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            fetchBucketAdjustmentdetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserEntersText(fetchBucketAdjustmentdetails["amount"], "ADJUST_BUCKET_VALUE_POPUP.BUCKET_ADJUSTMENT_VALUE");
            _iwebstep.GetService().ThenUserWaits("3");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(fetchBucketAdjustmentdetails["property"], "ADJUST_BUCKET_VALUE_POPUP.PROPERTY_DROPDOWN", "visibletext");
            if (fetchBucketAdjustmentdetails.ContainsKey("subbucket"))
            {

                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(fetchBucketAdjustmentdetails["subbucket"], "ADJUST_BUCKET_VALUE_POPUP.lstBucketsubtype", "visibletext");

            }
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('btnAdjust').click()");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            if (functionauthCheck.Equals("Y"))
            {
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_PASSWORD_TEXTBOX");
                switch (bucketname)
                {
                    case "<$Comps$>":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(fetchBucketAdjustmentdetails["reason"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_ADJUST_COMP_REASON", "visibletext");
                        break;
                    case "<$Tier$>":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(fetchBucketAdjustmentdetails["reason"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_ADJUST_TIER_POINT_REASON", "visibletext");
                        break;
                    case "<$GiftPoints$>":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(fetchBucketAdjustmentdetails["reason"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_ADJUST_INVENTORY_CASH_REASON", "visibletext");
                        break;
                    case "<$Points$>":
                        _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(fetchBucketAdjustmentdetails["reason"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_ADJUST_POINT_REASON", "visibletext");
                        break;
                    default:
                        throw new AutomationException("Un-Identified Bucket name. Please choose from the provided Bucketnames list.");
                }

                _iwebstep.GetService().GivenUserEntersText("Automation Test", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_COMMENT_TEXTAREA");
                _iwebstep.GetService().GivenUserClicksOn("AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_SUBMIT");
                _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
                _iwebstep.GetService().ThenUserWaits("5");
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
            }
            else
            {
                _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");

            }

        }


        [Then(@"Loyalty User adjust ""(.*)"" bucket with function Authorization check ""(.*)"" and universal check ""(.*)"" and expirydate ""(.*)"" with parameters")]
        public void ThenLoyaltyUserAdjustPromoBucketWithFunctionAuthorization(string bucket, string functionauthCheck, string universalcheck, string expirydatecheck, Table table)
        {
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADJUST_BUCKET_VALUE");
            _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(bucket, "ADJUST_BUCKET_VALUE_POPUP.BUCKET_TYPE_DROPDOWN", "visibletext");
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            fetchBucketAdjustmentdetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserEntersText(fetchBucketAdjustmentdetails["amount"], "ADJUST_BUCKET_VALUE_POPUP.BUCKET_ADJUSTMENT_VALUE");
            _iwebstep.GetService().ThenUserWaits("2");

            if (!universalcheck.Equals("Y"))
            {
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.UNIVERSAL_CHECKBOX");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(fetchBucketAdjustmentdetails["property"], "ADJUST_BUCKET_VALUE_POPUP.PROPERTY_DROPDOWN", "visibletext");
            }
            if (!expirydatecheck.Equals("Y"))
            {
                expiredate = fetchBucketAdjustmentdetails["expirydate"];
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.CHK_DEFAULT_EXP");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('txtExpirationDate').setAttribute('value', '')");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('txtExpirationDate').setAttribute('value', '" + expiredate + "')");
            }
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('btnAdjust').click()");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            if (functionauthCheck.Equals("Y"))
            {
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_PASSWORD_TEXTBOX");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(fetchBucketAdjustmentdetails["reason"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_ADJUST_PROMO_REASON", "visibletext");
                _iwebstep.GetService().GivenUserEntersText("Automation Test", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_COMMENT_TEXTAREA");
                _iwebstep.GetService().GivenUserClicksOn("AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_SUBMIT");
                _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
                _iwebstep.GetService().ThenUserWaits("4");
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
            }
            else
            {
                _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
            }

        }

        [Then(@"Loyalty User verify player ""(.*)"" bucketamount ""(.*)"" within bucket ""(.*)""")]
        public void ThenLoyaltyUserVerifyPlayerBucketamountWithinBucket(string player, string expectedbal, string bucket)
        {
            String actualbal = "";
            String actualbal2 = "";
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(player, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().GivenUserSwitchesToFrame("PLAYER_INFO.INFO_FRAME");

            switch (bucket)
            {
                case "<$Points$>":
                    _iwebstep.GetService();
                    _iwebstep.GetService().GivenUserVerifyAttribute("text", expectedbal, "PLAYER_INFO.BALANCES_POINTS");
                    break;

                case "<$Comps$>":
                    _iwebstep.GetService().GivenUserGetsAttributeElementToSaveWithKeyF("getText", "PLAYER_INFO.BALANCES_COMPS", actualbal);
                    _iwebstep.GetService().GivenUserSavesStringOperationsValue("cachevalueformat", "<$" + actualbal + "$>", "~_", actualbal2);
                    _iwebstep.GetService().GivenUserSavesStringOperationsValue("cachevalueformat", "<$" + actualbal2 + "$>", "numberfromamount", actualbal2);
                    _iwebstep.GetService().GivenUserPerformOperations("numberEquals", "<$" + actualbal2 + "$>", expectedbal);
                    break;
                case "<$Tier$>":
                    _iwebstep.GetService().GivenUserVerifyAttribute("text", "expectedbal", "PLAYER_INFO.TIER_CREDITS");
                    break;

                case "<$GiftPoints$>":
                    _iwebstep.GetService().GivenUserVerifyAttribute("text", "expectedbal", "PLAYER_INFO.INVENTORY_CASH_CREDIT");
                    break;

                case "<$Promo$>":
                    _iwebstep.GetService().GivenUserGetsAttributeElementToSaveWithKeyF("getText", "PLAYER_INFO.BALANCES_PROMO", actualbal);
                    _iwebstep.GetService().GivenUserSavesStringOperationsValue("cachevalueformat", "<$" + actualbal + "$>", "~_", actualbal2);
                    _iwebstep.GetService().GivenUserSavesStringOperationsValue("cachevalueformat", "<$" + actualbal2 + "$>", "numberfromamount", actualbal2);
                    _iwebstep.GetService().GivenUserPerformOperations("numberEquals", "<$" + actualbal2 + "$>", "<$" + expectedbal + "$>");
                    break;

                default:
                    throw new AutomationException("Un-Identified Bucket name. Please choose from the provided Bucketnames list.");
            }
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
        }


        [When(@"Loyalty User adjust player ""(.*)"" tierlevel to ""(.*)"" with function Authorization check ""(.*)"" with parameters")]
        public void WhenLoyaltyUserAdjustPlayerTier(string universalplayer, string tierlevel, string functionauthCheck, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            adjustTierlevel = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADJUST_PLAYER_TIER");
            _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_TIER.ADJUST_TIER_FRAME");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(tierlevel, "ADJUST_TIER.TIER_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(adjustTierlevel["locktype"], "ADJUST_TIER.LOCK_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("ADJUST_TIER.ADJUST_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            if (functionauthCheck.Equals("Y"))
            {
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_PASSWORD_TEXTBOX");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(adjustTierlevel["reason"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_ADJUST_TIER_REASON", "visibletext");
                _iwebstep.GetService().GivenUserEntersText("Test Automation", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_COMMENT_TEXTAREA");
                _iwebstep.GetService().GivenUserClicksOn("AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_SUBMIT");
                _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
                _iwebstep.GetService().ThenUserWaits("5");
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_TIER.ADJUST_PROCESS_OK");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");

            }
            else
            {
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_TIER.ADJUST_PROCESS_OK");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            }
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("PLAYER_INFO.INFO_FRAME");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", tierlevel, "PLAYER_INFO.PLAYER_TIER_SPAN");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Club Info", "CLUB_INFO.SECTION_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserVerifyAttribute("text", tierlevel, "CLUB_INFO.CURRENT_TIER_LABEL");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.TIER_HISTORY_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("TIER_HISTORY.TIER_HISTORY_FRAME");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("TIER_HISTORY.TIER_HISTORY_TABLE_ROW", ConvertStringtoTable("tdate:" + adjustTierlevel["date"], "type:" + adjustTierlevel["type"], "previousTier:" + adjustTierlevel["oldtier"], "newTier:" + tierlevel, "authorizer:" + adjustTierlevel["username"], "lockUntil:" + adjustTierlevel["lockexpiry"], "lockType:" + adjustTierlevel["locktype"], "reason:" + adjustTierlevel["reason"]));
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
        }

        [When(@"EB User perform adjustment with function Authorization check ""(.*)"" with parameters")]
        public void WhenLEBUserPerformAdjustmentWithFunctionAuthorization(string functionauthCheck, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            BucketAdjustmentdetails = _iteststep.GetMultiRowDataTable()[0];
            //Moving to Bucket value Adjustment screen.
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADJUST_BUCKET_VALUE");
            _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.BUCKET_TYPE_DROPDOWN");
            _iwebstep.GetService().GivenUserEntersText(BucketAdjustmentdetails["bucketview"], "ADJUST_BUCKET_VALUE_POPUP.Search_Bucket/Consolidated");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("ADJUST_BUCKET_VALUE_POPUP.EB_dropdown_Option", ConvertStringtoTable("option:" + BucketAdjustmentdetails["bucketview"]));
            _iwebstep.GetService().ThenUserWaits("2");
            if (BucketAdjustmentdetails.ContainsKey("bucket"))
            {
                _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.lstBucketsubtype");
                _iwebstep.GetService().GivenUserClicksOnWithParameters("ADJUST_BUCKET_VALUE_POPUP.EB_dropdown_Option", ConvertStringtoTable("option:" + BucketAdjustmentdetails["bucket"]));
            }
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROPERTY_DROPDOWN");
            _iwebstep.GetService().GivenUserEntersText(BucketAdjustmentdetails["property"], "ADJUST_BUCKET_VALUE_POPUP.Search_Propertydropdown");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("ADJUST_BUCKET_VALUE_POPUP.EB_dropdown_Option", ConvertStringtoTable("option:" + BucketAdjustmentdetails["property"]));
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserEntersText(BucketAdjustmentdetails["amount"], "ADJUST_BUCKET_VALUE_POPUP.BUCKET_ADJUSTMENT_VALUE");
            if(functionauthCheck == "Y")
            {
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_PASSWORD_TEXTBOX");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(BucketAdjustmentdetails["reason"], "ADJUST_BUCKET_VALUE_POPUP.REASON_DROPDOWN", "visibletext");
                _iwebstep.GetService().GivenUserEntersText(BucketAdjustmentdetails["comment"], "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_COMMENT_TEXTAREA");
            }
            _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.btn_Adjust");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().WhenUserPerformActionBrowser("refresh");
        }

        [When(@"EB User link player with parameters")]
        public void EBLinkPlayer(Table parameters)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(parameters).Build();
            linkplayerdetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserRunsQuery("select top 1 LinkPlayerReason from  UC_X_LinkedPlayerReason where Active =1 order by NEWID()", "<#Halo_db_connectionstring#>", "LinkPlayerReason");
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(linkplayerdetails["player 1"], "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().GivenUserEntersText("Link Player", "MAIN_NAV_BOX.EB_MenuSearch");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.LINK_PLAYER_LINK");
            _iwebstep.GetService().GivenUserSwitchesToFrame("LINK_PLAYER_POPUP.LINK_PLAYER_FRAME");
            _iwebstep.GetService().GivenUserEntersText(linkplayerdetails["player 2"], "LINK_PLAYER_POPUP.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("LINK_PLAYER_POPUP.PLAYER_LOOKUP_IMAGE");
            _iwebstep.GivenUserSelectsOptionsOfElementBy(linkplayerdetails["link type"], "LINK_PLAYER_POPUP.LINK_TYPE_DROPDOWN", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("LINK_PLAYER_POPUP.OK_BUTTON");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserSwitchesToFrame("AUTHORIZATION_POPUP.Authorization_Frame");
            _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_PASSWORD_TEXTBOX");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("<$LinkPlayerReason$>", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_LINK_REASON", "visibletext");
            _iwebstep.GetService().GivenUserEntersText("Automation Test", "AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_COMMENT_TEXTAREA");
            _iwebstep.GetService().GivenUserClicksOn("AUTHORIZATION_POPUP.AUTHORIZATION_POPUP_SUBMIT");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserSwitchesToFrame("ADJUST_BUCKET_VALUE_POPUP.ADJUST_BUCKET_VALUE_FRAME");
            _iwebstep.GetService().GivenUserClicksOn("ADJUST_BUCKET_VALUE_POPUP.PROCESS_SUBMIT");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().WhenUserPerformActionBrowser("refresh");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.LinkPlayerLink");
            _iwebstep.GetService().ThenUserWaits("4");
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("DASHBOARD.LinkedPlayerId", "true", ConvertStringtoTable("UPlayerID:" + linkplayerdetails["player 2"]));
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.LinkPlayerPopUpClose");
        }

    }
}

