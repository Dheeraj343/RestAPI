﻿using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.WebAbstraction;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty
{
    [Binding]
    public class Exclusion : LoyaltyBase
    {
        ITestStepBuilder _iteststepbuilder;
        ITestStep _iteststep;
        IWebStepDef _iwebstep;
        Dictionary<string, string> exclusionPlandetails = new Dictionary<string, string>();
        String startdate = "";
        String enddate = "";

        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();

        }

        [Given(@"Loyalty User create Configurable Exclusionplan ""(.*)"" with includeallEvent check ""(.*)"" and includeallProperty check ""(.*)"" with parameters")]
        public void GivenLoyaltyUserCreateConfigurableExclusionplan(string planname, string includeallEvent, string functionAuth, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            exclusionPlandetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADMINISTRATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.lnkExclusionMangement");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.lnkAddConfigurableplan");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnAddexclusionplan");
            _iwebstep.GetService().GivenUserEntersText(planname, "hlw1dot4Exclusionplan.txtExclusionplan_name");
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.chkExclusionplan_active");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.lstExclusionplan_Noneselectedproperty");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.lstExclusionplan_Noneselectedproperty");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("hlw1dot4Exclusionplan.lstExclusionplan_property", ConvertStringtoTable("optionName:" + exclusionPlandetails["property"]));
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.txtExclusionplan_comment");
            _iwebstep.GetService().GivenUserEntersText(exclusionPlandetails["comment"], "hlw1dot4Exclusionplan.txtExclusionplan_comment");
            if ((exclusionPlandetails.ContainsKey("timeframe")) && (exclusionPlandetails.ContainsKey("timeframevalue")))
            {
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(exclusionPlandetails["timeframe"], "hlw1dot4Exclusionplan.drpdown_ExclusionTimeframe", "visibletext");
                _iwebstep.GetService().GivenUserEntersText(exclusionPlandetails["timeframevalue"], "hlw1dot4Exclusionplan.txt_ExclusionTimeFrameValue");
            }
            else
            {
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy("Days", "hlw1dot4Exclusionplan.drpdown_ExclusionTimeframe", "visibletext");
                _iwebstep.GetService().GivenUserEntersText("7", "hlw1dot4Exclusionplan.txt_ExclusionTimeFrameValue");

            }
            if (includeallEvent.Equals("Y"))
            {
                _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnExclusionplan_includeAll");

            }
            else if ((exclusionPlandetails.ContainsKey("action1")) && (exclusionPlandetails.ContainsKey("action2")))
            {
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(exclusionPlandetails["action1"], "hlw1dot4Exclusionplan.lstExclusionplan_excludedAction", "visibletext");
                _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnExclusionplan_includeFilter");
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(exclusionPlandetails["action2"], "hlw1dot4Exclusionplan.lstExclusionplan_excludedAction", "visibletext");
                _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnExclusionplan_includeFilter");
            }
            else if (exclusionPlandetails.ContainsKey("action1"))
            {
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(exclusionPlandetails["action1"], "hlw1dot4Exclusionplan.lstExclusionplan_excludedAction", "visibletext");
                _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnExclusionplan_includeFilter");
            }
            else { }
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnExclusionplan_save");
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("hlw1dot4Exclusionplan.lblExclusionplan_savemessage", "true", ConvertStringtoTable("message:" + exclusionPlandetails["message"]));
            _iwebstep.GetService().ThenUserWaits("1");

        }

        [When(@"Loyalty User inactivate Configurabe Exclusionplan ""(.*)"" with parameters")]
        public void WhenLoyaltyUserInactivateConfigurabeExclusionplanWithParameters(string plan, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            exclusionPlandetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADMINISTRATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.lnkExclusionMangement");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.lnkAddConfigurableplan");
            _iwebstep.GetService().GivenUserEntersText(plan, "hlw1dot4Exclusionplan.txtSearchexclusionplan_namefilter");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(exclusionPlandetails["activeflag"], "hlw1dot4Exclusionplan.lstSearchexclusionplan_Activefilter", "visibletext");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("hlw1dot4Exclusionplan.tblsearchExclusionplan_selectedrow", ConvertStringtoTable("planName:" + plan, "property:" + exclusionPlandetails["property"], "comment:" + exclusionPlandetails["comment"]));
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("hlw1dot4Exclusionplan.lblExclusionplan_savemessage", "true", ConvertStringtoTable("message:" + exclusionPlandetails["message"]));


        }

        [Then(@"Loyalty User assigns exclusionplan ""(.*)"" to player ""(.*)"" with function Authorization check ""(.*)"" and Enddate check ""(.*)"" and verify flag with parameters")]
        public void ThenLoyaltyUserAssignsExclusionplan(string plan, string player, string functionauthCheck, string enddateCheck, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            exclusionPlandetails = _iteststep.GetMultiRowDataTable()[0];
            startdate = exclusionPlandetails["startdate"];
            enddate = exclusionPlandetails["endingdate"];
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(player, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.lnkManagePlayerExclusion");
            _iwebstep.GetService().GivenUserSwitchesToFrame("hlw1dot4Exclusionplan.frmAddExclusionplan_player");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnAddplan_player");
            if (exclusionPlandetails.ContainsKey("PlanExists"))
            {
                if (exclusionPlandetails["PlanExists"].Equals("true"))
                {
                    _iwebstep.GetService().ThenUserVerifiesElement("hlw1dot4Exclusionplan.lblExclusionplan_playerassign", "false");
                }
                else
                {
                    _iwebstep.GetService().ThenUserVerifiesElement("hlw1dot4Exclusionplan.lblExclusionplan_playerassign", "true");
                }
            }
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(plan, "hlw1dot4Exclusionplan.lstadd_Exclusionplanname", "visibletext");

            if (exclusionPlandetails.ContainsKey("multiProperty"))
            {
                if (!(exclusionPlandetails["multiProperty"].Equals("All")))
                {
                    _iwebstep.GetService().GivenUserVerifyAttribute("text", exclusionPlandetails["property"], "hlw1dot4Exclusionplan.txtaddExclusionplan_propertyname");
                }
            }

            _iwebstep.GetService().ThenUserWaits("3");
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('txtStartDate').click()");
            _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('txtStartDate').setAttribute('value', '" + startdate + "')");
            _iwebstep.GetService().ThenUserWaits("5");
            if (enddateCheck.Equals("Y"))
            {
                _iwebstep.GetService().GivenSelectElement("selects", "hlw1dot4Exclusionplan.chkAddplan_noenddate");
                _iwebstep.GetService().ThenUserWaits("2");
                _iwebstep.GetService().GivenUserVerifyAttribute("disabled", "true", "hlw1dot4Exclusionplan.txtAddexclusionplan_Enddate");
            }
            else if (enddateCheck.Equals("N") && enddate.Equals(""))
            { }
            else
            {
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('txtEndDate').click()");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('txtEndDate').setAttribute('value', '')");
                _iwebstep.GetService().WhenUserExecutesJavascript("document.getElementById('txtEndDate').setAttribute('value', '" + enddate + "')");
                _iwebstep.GetService().WhenUserPressKey("tab");
            }
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnExclusionplan_save");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            if (functionauthCheck.Equals("Y"))
            {
                _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "hlw1dot4Exclusionplan.txtAddplan_functionauthpassword");
                _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(exclusionPlandetails["reason"], "hlw1dot4Exclusionplan.txtAddplan_functionauthreason", "visibletext");
                _iwebstep.GetService().GivenUserEntersText(exclusionPlandetails["comment"], "hlw1dot4Exclusionplan.txtAddplan_functionauthcomment");
                _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnAddplan_functionauth_submit");
            }

            _iwebstep.GetService().GivenUserSwitchesToFrame("hlw1dot4Exclusionplan.frmAddExclusionplan_player");
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("hlw1dot4Exclusionplan.lblExclusionplan_savemessage", "true", ConvertStringtoTable("message:" + exclusionPlandetails["message"]));
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnClose_exclusionplan");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("PLAYER_INFO.INFO_FRAME");
            if (plan.Equals("DAP") || plan.Equals("Self-Exclusion"))
            {
                _iwebstep.GetService().GivenUserClicksOn("PLAYER_INFO.DAP_FLAG");
            }
            else if (plan.Contains("Prop 86"))
            {
                _iwebstep.GetService().GivenUserClicksOn("PLAYER_INFO.btnProp86flag");
            }
            else
            {
                _iwebstep.GetService().GivenUserVerifyAttribute("value", exclusionPlandetails["flagname"], "PLAYER_INFO.lnkFI_flag");
                _iwebstep.GetService().GivenUserClicksOn("PLAYER_INFO.lnkFI_flag");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                _iwebstep.GetService().GivenUserSwitchesToFrame("hlw1dot4Exclusionplan.frmAddExclusionplan_player");
                _iwebstep.GetService().ThenUserVerifiesElementWithParameters("hlw1dot4Exclusionplan.tblplayerdahboard_exclusionplanadded", "true", ConvertStringtoTable("planName:" + plan, "property:" + exclusionPlandetails["property"], "startDate:" + exclusionPlandetails["uistartdate"], "stDateFormat:" + startdate, "endDate:" + ""));
                _iwebstep.GetService().GivenUserClicksOnWithParameters("hlw1dot4Exclusionplan.tblplayerdahboard_exclusionplanadded", ConvertStringtoTable("planName:" + plan, "property:" + exclusionPlandetails["property"], "startDate:" + exclusionPlandetails["uistartdate"], "stDateFormat:" + startdate, "endDate:" + ""));
                if (exclusionPlandetails.ContainsKey("flagdetails"))
                {
                    _iwebstep.GetService().ThenUserVerifiesElementWithParameters("hlw1dot4Exclusionplan.tblplayerdahboard_exclusionplanadded", "true", ConvertStringtoTable("planName:" + plan, "property:" + exclusionPlandetails["property"], "startDate:" + exclusionPlandetails["uistartdate"], "stDateFormat:" + startdate, "endDate:" + exclusionPlandetails["uienddate"]));
                    _iwebstep.GetService().GivenUserClicksOnWithParameters("hlw1dot4Exclusionplan.tblplayerdahboard_exclusionplanadded", ConvertStringtoTable("planName:" + plan, "property:" + exclusionPlandetails["property"], "startDate:" + exclusionPlandetails["uistartdate"], "stDateFormat:" + startdate, "endDate:" + exclusionPlandetails["uienddate"]));
                }
                if (exclusionPlandetails.ContainsKey("multiProperty"))
                {
                    if (!(exclusionPlandetails["multiProperty"].Equals("All")))
                    {
                        _iwebstep.GetService().GivenUserVerifyAttribute("text", exclusionPlandetails["property"], "hlw1dot4Exclusionplan.txtPlayer_exclusionplanviewproperty");
                    }
                }
                _iwebstep.GetService().ThenUserWaits("1");
                _iwebstep.GetService().GivenUserVerifyAttribute("text", exclusionPlandetails["comment"], "hlw1dot4Exclusionplan.txtPlayer_exclusionplanviewcomment");
                _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnPlayer_exclusionplanviewcancel");
                _iwebstep.GetService().GivenUserSwitchesToFrame("default");
                _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnClose_exclusionplan");
            }

        }

        [Then(@"Loyalty User remove exclusionplan ""(.*)"" from player ""(.*)"" with function Authorization check ""(.*)"" and verify flag disabled with parameters")]
        public void ThenLoyaltyUserRemoveExclusionplanFromPlayer(string plan, string player, string functionauthCheck, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            exclusionPlandetails = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(player, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.lnkManagePlayerExclusion");
            _iwebstep.GetService().GivenUserSwitchesToFrame("hlw1dot4Exclusionplan.frmAddExclusionplan_player");
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("hlw1dot4Exclusionplan.tblAddplan_playerexclusionplanrow", "true", ConvertStringtoTable("planName:" + plan, "property:" + exclusionPlandetails["property"], "startDate:" + exclusionPlandetails["startdate"], "endDate:" + exclusionPlandetails["enddate"]));
            _iwebstep.GetService().GivenUserClicksOnWithParameters("hlw1dot4Exclusionplan.tblAddplan_playerexclusionplanrow", ConvertStringtoTable("planName:" + plan, "property:" + exclusionPlandetails["property"], "startDate:" + exclusionPlandetails["startdate"], "endDate:" + exclusionPlandetails["enddate"]));
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserEntersText("<#Halo_username#>", "hlw1dot4Exclusionplan.txtRemoveplayer_exclusionplanuserid");
            _iwebstep.GetService().GivenUserEntersText("<#Halo_password#>", "hlw1dot4Exclusionplan.txtRemoveplayer_exclusionplanpassword");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(exclusionPlandetails["reason"], "hlw1dot4Exclusionplan.txtRemoveplan_functionauthreason", "visibletext");
            _iwebstep.GetService().GivenUserEntersText(exclusionPlandetails["comment"], "hlw1dot4Exclusionplan.txtRemoveplayer_exclusionplancomment");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnAddplan_functionauth_submit");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserSwitchesToFrame("hlw1dot4Exclusionplan.frmAddExclusionplan_player");
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("hlw1dot4Exclusionplan.lblExclusionplan_savemessage", "true", ConvertStringtoTable("message:" + exclusionPlandetails["message"]));
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserClicksOn("hlw1dot4Exclusionplan.btnClose_exclusionplan");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.PLAYER_INFO_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("PLAYER_INFO.INFO_FRAME");
            _iwebstep.GetService().ThenUserVerifiesElement("PLAYER_INFO.lnkFI_flag", "false");
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");

        }

        [When(@"Loyalty User change player ""(.*)"" status to ""(.*)""")]
        private void DeceasedPlayer(String player, String status)
        {
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(player, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
            _iwebstep.GetService().GivenUserClicksOn("DASHBOARD.CONTACT_INFO_TAB");
            _iwebstep.GetService().GivenUserSwitchesToFrame("CONTACT_INFO.CONTACT_INFO_FRAME");
            _iwebstep.GetService().GivenUserClicksOn("CONTACT_INFO.CONTACT_DECEASED_CHECKBOX");
            _iwebstep.GetService().GivenUserClicksOn("CONTACT_INFO.CONTACT_INFO_SAVE");
        }


    }


}

