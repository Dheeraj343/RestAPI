﻿using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.WebAbstraction;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty
{
    [Binding]
    public class ValidateLogs : LoyaltyBase
    {
        ITestStepBuilder _iteststepbuilder;
        ITestStep _iteststep;
        IWebStepDef _iwebstep;
        Dictionary<string, string> userTransactionLogs = new Dictionary<string, string>();
        Dictionary<string, string> playerTransactionLogs = new Dictionary<string, string>();

        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();

        }

        [Then(@"Loyalty User validate UserTransactionLogs for player ""(.*)"" and user ""(.*)"" and filtername ""(.*)"" with parameters")]
        public void ThenLoyaltyUserValidateLogs(string universalPlayer, string username, string filtername, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            userTransactionLogs = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.LNK_USER_TRANSCATION_LOG");
            _iwebstep.GetService().WhenUserClears("USER_TRANS_LOG.TXT_USERID");
            _iwebstep.GetService().GivenUserEntersText(username, "USER_TRANS_LOG.TXT_USERID");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(userTransactionLogs["date"], "USER_TRANS_LOG.DRP_DATE_RANGED", "visibletext");
            _iwebstep.GetService().GivenUserClicksOn("USER_TRANS_LOG.BTN_SEARH");
            _iwebstep.GetService().GivenUserClicksOn("USER_TRANS_LOG.PLAYER_ID_FILTER");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("USER_TRANS_LOG.PLAYER_ID_FILTER_OPTIONS", ConvertStringtoTable("OptionName:" + userTransactionLogs["optionname"]));
            _iwebstep.GetService().WhenUserClears("USER_TRANS_LOG.TXT_PLAYER_ID_FILTER");
            _iwebstep.GetService().GivenUserEntersText(universalPlayer, "USER_TRANS_LOG.TXT_PLAYER_ID_FILTER");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().WhenUserPressKey("enter");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("USER_TRANS_LOG.ROW_EXPAND_IMG", ConvertStringtoTable("CropProp:" + userTransactionLogs["cropprop"], "Userid:" + username, "Transaction:" + userTransactionLogs["transaction"], "PlayerId:" + universalPlayer, "Date:" + ""));
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("USER_TRANS_LOG.VALUE_BEFORE_AFTER_ROW", "true", ConvertStringtoTable("ApprovedBy:" + userTransactionLogs["approvedby"], "ValueAfter:" + userTransactionLogs["valueafter"], "ValueBefore:" + userTransactionLogs["valuebefore"]));
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(universalPlayer, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");

        }

        [Then(@"Loyalty User validate PlayerTransactionLogs for player ""(.*)"" and user ""(.*)"" with parameters")]
        public void ThenLoyaltyUserValidateLogs(string universalPlayer, string username, Table table)
        {
            _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(table).Build();
            playerTransactionLogs = _iteststep.GetMultiRowDataTable()[0];
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_FUNCTIONS_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.PLAYER_TRANSACTIONS_LOG");
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("PLAYERTRANS_LOG.PLAYER_TRANSACTION_PLAYERID_LABEL", "true", ConvertStringtoTable("PlayerId:" + universalPlayer));
            _iwebstep.GetService().GivenUserSwitchesToFrame("PLAYERTRANS_LOG.PLAYER_TRANSACTIONLOG_FRAME");
            _iwebstep.GetService().ThenUserVerifiesElement("PLAYERTRANS_LOG.PLAYER_TRANSACTION_HEADER_DATA", "true");
            _iwebstep.GetService().GivenUserClicksOn("USER_TRANS_LOG.PLAYER_ID_FILTER");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("USER_TRANS_LOG.PLAYER_ID_FILTER_OPTIONS", ConvertStringtoTable("OptionName:" + playerTransactionLogs["optionname"]));
            _iwebstep.GetService().WhenUserClears("USER_TRANS_LOG.TXT_PLAYER_ID_FILTER");
            _iwebstep.GetService().GivenUserEntersText(playerTransactionLogs["transaction"], "USER_TRANS_LOG.TXT_PLAYER_ID_FILTER");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().WhenUserPressKey("enter");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserClicksOnWithParameters("PLAYERTRANS_LOG.PLAYER_TRANSACTION_ROW_EXPANDIMAGE", ConvertStringtoTable("Date:" + playerTransactionLogs["date"], "Transactions:" + playerTransactionLogs["transaction"], "UserID:" + username, "CorpProp:" + playerTransactionLogs["cropprop"]));
            _iwebstep.GetService().ThenUserWaits("2");
            _iwebstep.GetService().ThenUserVerifiesElementWithParameters("PLAYERTRANS_LOG.PLAYER_TRANSACTION_TRANSDETAILS_ROW", "true", ConvertStringtoTable("Transactions:" + playerTransactionLogs["transaction"], "SubTransaction:" + playerTransactionLogs["valueafter"]));
            _iwebstep.GetService().GivenUserClicksOnWithParameters("PLAYERTRANS_LOG.PLAYER_TRANSACTION_TRANSDETAILS_ROW", ConvertStringtoTable("Transactions:" + playerTransactionLogs["transaction"], "SubTransaction:" + playerTransactionLogs["valueafter"]));
            _iwebstep.GetService().GivenUserSwitchesToFrame("default");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.CLOSE_BUTTON");
            _iwebstep.GetService().WhenUserClears("PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(universalPlayer, "PLAYER_SEARCH.PLAYER_ID_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("PLAYER_SEARCH.PLAYER_SEARCH_BUTTON");
        }











    }


}

