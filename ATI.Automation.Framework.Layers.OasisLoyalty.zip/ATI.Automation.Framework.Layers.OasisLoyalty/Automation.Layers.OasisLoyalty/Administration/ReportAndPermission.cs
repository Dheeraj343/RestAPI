﻿using Automation.Framework.Core.Web.Runner;
using Automation.Framework.Core.Web.WebAbstraction;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace Automation.Layers.OasisLoyalty
{
    [Binding]
    public class ReportAndPermission : LoyaltyBase
    {
        ITestStepBuilder _iteststepbuilder;
        ITestStep _iteststep;
        IWebStepDef _iwebstep;
        Dictionary<string, string> reportFilter = new Dictionary<string, string>();

        [BeforeStep]
        public void BeforeStep(ScenarioContext stepcontext)
        {
            _iteststepbuilder = Cucumber._serviceprovider.GetService<ITestStepBuilder>();
            _iteststep = Cucumber._serviceprovider.GetService<ITestStep>();
            _iwebstep = Cucumber._serviceprovider.GetService<IWebStepDef>();

        }


        [When(@"Loyalty User ""(.*)"" Permission ""(.*)"" with User Group ""(.*)""")]
        public void checkPermission(String action, String permission, String group)
        {
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADMINISTRATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.GROUP_PERMISSIONS_LINK");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(group, "USER_GROUP_PERMISSIONS.USER_GROUP_DROPDOWN", "visibletext");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserClicksOn("USER_GROUP_PERMISSIONS.EDIT_FUNCTIONS_BUTTON");
            _iwebstep.GetService().WhenUserClears("USER_GROUP_PERMISSIONS.PERMISSION_SEARCH_TEXTBOX");
            _iwebstep.GetService().GivenUserEntersText(permission, "USER_GROUP_PERMISSIONS.PERMISSION_SEARCH_TEXTBOX");
            _iwebstep.GetService().GivenUserClicksOn("USER_GROUP_PERMISSIONS.PERMISSION_SEARCH_BUTTON");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().ThenUserElementWithElement(action, "USER_GROUP_PERMISSIONS.chkTransportpermission", ConvertStringtoTable("permissionname:" + permission));
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserClicksOn("USER_GROUP_PERMISSIONS.SAVE_BUTTON");


        }


        [When(@"Loyalty User launch ""(.*)"" with following filter")]
        public void launchReport(String report, Table datatables)
        {
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.ADMINISTRATION_LINK");
            _iwebstep.GetService().GivenUserClicksOn("MAIN_NAV_BOX.REPORTS_LINK");
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(report, "REPORTS_GENERATION_UI.SELECT_REPORT_LIST", "visibletext");
            _iwebstep.GetService().ThenUserWaits("1");
            if (datatables.Rows.Count != 0)
            {
                _iwebstep.GetService();
                _iteststep = _iteststepbuilder.SetMultiRowStepDataTable(datatables).Build();
                reportFilter = _iteststep.GetMultiRowDataTable()[0];
                if (reportFilter.ContainsKey("fromdate"))
                    _iwebstep.GetService().GivenUserEntersText(reportFilter["fromdate"], "REPORTS_GENERATION_UI.FROM_DATE_TEXTBOX");
                if (reportFilter.ContainsKey("todate"))
                    _iwebstep.GetService().GivenUserEntersText(reportFilter["todate"], "REPORTS_GENERATION_UI.TO_DATE_TEXTBOX");
                if (reportFilter.ContainsKey("propertyname"))
                {
                    _iwebstep.GetService().GivenUserSelectsOptionsOfElementBy(reportFilter["propertyname"], "REPORTS_GENERATION_UI.PROPERTY_LIST", "visibletext");
                    _iwebstep.GetService().GivenUserClicksOn("REPORTS_GENERATION_UI.PROPERTY_LIST_ADD_ARROW");
                    _iwebstep.GetService().ThenUserWaits("1");
                }
                if (reportFilter.ContainsKey("playerid"))
                    _iwebstep.GetService().GivenUserEntersText(reportFilter["playerid"], "REPORTS_GENERATION_UI.PLAYER_ID_TEXTBOX");
            }
            _iwebstep.GetService().ThenUserWaits("1");
            _iwebstep.GetService().GivenUserClicksOn("REPORTS_GENERATION_UI.LAUNCH_BUTTON");
            _iwebstep.GetService().ThenUserWaits("10");
            _iwebstep.GivenUserClicksOnWithParameters("REPORTS.REPORT_NAME_DIV", ConvertStringtoTable("name:" + report));
        }



    }
}